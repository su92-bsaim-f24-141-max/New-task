"""
=============================================================================
  SMART VOLUNTEER DISPATCH - ML MODEL TRAINING SCRIPT
  Author: Asad (BSAI 4C, Roll No: 141)
  Instructor: Rasikh Ali
  
  This script trains a Multinomial Naive Bayes classifier using TF-IDF
  vectorization to classify emergency descriptions into categories.
  
  Categories: medical, fire, flood, food_distribution
  
  Steps demonstrated:
  1. Load dataset from CSV
  2. Train/Test split
  3. TF-IDF Vectorization (text to numbers)
  4. MultinomialNB classifier training
  5. Accuracy calculation
  6. Classification Report
  7. Confusion Matrix visualization
  8. Save model and vectorizer using joblib
=============================================================================
"""

import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend for saving plots
import matplotlib.pyplot as plt
import seaborn as sns

# ============================================================
# PATHS
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
MODEL_DIR = os.path.join(BASE_DIR, 'models')
PLOT_DIR = os.path.join(BASE_DIR, 'static', 'plots')

# Make sure directories exist
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(PLOT_DIR, exist_ok=True)

# File paths
CSV_PATH = os.path.join(DATA_DIR, 'emergency_data.csv')
MODEL_PATH = os.path.join(MODEL_DIR, 'emergency_model.pkl')
VECTORIZER_PATH = os.path.join(MODEL_DIR, 'vectorizer.pkl')
CONFUSION_MATRIX_PATH = os.path.join(PLOT_DIR, 'confusion_matrix.png')


def generate_dataset_if_missing():
    """
    Generate synthetic dataset if the CSV file doesn't exist.
    This ensures the project works out of the box.
    """
    if not os.path.exists(CSV_PATH):
        print("[Dataset not found. Generating synthetic data...]")
        # The dataset is already in the repo, but we create a fallback
        data = {
            'description': [
                'A patient collapsed due to heart attack and needs immediate CPR',
                'There is a massive fire in the apartment building',
                'The river has overflowed and flooded the neighborhood',
                'Families are starving and need urgent food distribution',
                'A child is having severe breathing difficulty',
                'The warehouse is on fire with thick black smoke',
                'Heavy monsoon rains caused flash flooding in the city',
                'The refugee camp is running out of food supplies',
                'An elderly person fell down the stairs with a hip fracture',
                'Forest fire is spreading rapidly toward residential area',
                'The dam water level is rising and flooding downstream',
                'School children need meals after the disaster',
                'A construction worker got electrocuted and is unconscious',
                'The shopping mall has caught fire during business hours',
                'Coastal flooding has damaged homes and people are stranded',
                'The community shelter needs food packages for families',
                'A woman is experiencing pregnancy complications',
                'Multiple vehicles collided and one car is on fire',
                'Drainage system failed causing urban flooding',
                'Food banks are empty and homeless people need food',
            ],
            'category': [
                'medical', 'fire', 'flood', 'food_distribution',
                'medical', 'fire', 'flood', 'food_distribution',
                'medical', 'fire', 'flood', 'food_distribution',
                'medical', 'fire', 'flood', 'food_distribution',
                'medical', 'fire', 'flood', 'food_distribution',
            ]
        }
        df = pd.DataFrame(data)
        df.to_csv(CSV_PATH, index=False)
        print(f"[Dataset created at {CSV_PATH}]")
    
    return CSV_PATH


def load_data(csv_path):
    """
    Step 1: Load the emergency dataset from CSV.
    
    The dataset has two columns:
    - description: Text describing the emergency
    - category: The type of emergency (medical, fire, flood, food_distribution)
    """
    print("\n" + "=" * 60)
    print("STEP 1: LOADING DATASET")
    print("=" * 60)
    
    df = pd.read_csv(csv_path)
    print(f"\n  Dataset shape: {df.shape[0]} rows x {df.shape[1]} columns")
    print(f"\n  Columns: {list(df.columns)}")
    print(f"\n  Category distribution:")
    print(df['category'].value_counts().to_string())
    print(f"\n  First 3 descriptions:")
    for i, row in df.head(3).iterrows():
        print(f"    [{row['category']}] {row['description'][:80]}...")
    
    return df


def split_data(df):
    """
    Step 2: Split data into training and testing sets.
    
    - 80% for training the model
    - 20% for testing the model
    - stratify ensures equal category distribution in both sets
    """
    print("\n" + "=" * 60)
    print("STEP 2: TRAIN/TEST SPLIT")
    print("=" * 60)
    
    X = df['description']   # Features (text descriptions)
    y = df['category']      # Labels (emergency categories)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"\n  Training set size: {len(X_train)} samples")
    print(f"  Testing set size:  {len(X_test)} samples")
    print(f"\n  Training category distribution:")
    print(y_train.value_counts().to_string())
    print(f"\n  Testing category distribution:")
    print(y_test.value_counts().to_string())
    
    return X_train, X_test, y_train, y_test


def vectorize_text(X_train, X_test):
    """
    Step 3: Convert text to numerical features using TF-IDF.
    
    TF-IDF = Term Frequency - Inverse Document Frequency
    - TF: How often a word appears in a document
    - IDF: How rare a word is across all documents
    - stop_words='english': Remove common English words (the, is, at, etc.)
    - max_features=5000: Use top 5000 most important words
    """
    print("\n" + "=" * 60)
    print("STEP 3: TF-IDF VECTORIZATION")
    print("=" * 60)
    
    vectorizer = TfidfVectorizer(
        max_features=5000,       # Use top 5000 features
        stop_words='english',    # Remove common English stop words
        ngram_range=(1, 2),      # Use single words and bigrams
        lowercase=True           # Convert all text to lowercase
    )
    
    # Fit on training data, transform both train and test
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    print(f"\n  Vocabulary size: {len(vectorizer.vocabulary_)} features")
    print(f"  Training matrix shape: {X_train_vec.shape}")
    print(f"  Testing matrix shape:  {X_test_vec.shape}")
    print(f"\n  Sample features (first 10):")
    feature_names = vectorizer.get_feature_names_out()
    for word in sorted(feature_names)[:10]:
        idx = vectorizer.vocabulary_[word]
        print(f"    '{word}' -> feature index: {idx}")
    
    return vectorizer, X_train_vec, X_test_vec


def train_classifier(X_train_vec, y_train):
    """
    Step 4: Train Multinomial Naive Bayes classifier.
    
    MultinomialNB works well for text classification because:
    - It handles count/frequency data naturally
    - It's fast and efficient
    - It works well with TF-IDF features
    - Based on Bayes' Theorem: P(category|text) ∝ P(text|category) * P(category)
    """
    print("\n" + "=" * 60)
    print("STEP 4: TRAINING MULTINOMIAL NAIVE BAYES")
    print("=" * 60)
    
    model = MultinomialNB(alpha=1.0)  # alpha=1.0 is Laplace smoothing
    model.fit(X_train_vec, y_train)
    
    print(f"\n  Model trained successfully!")
    print(f"  Model type: MultinomialNB")
    print(f"  Classes: {list(model.classes_)}")
    print(f"\n  Class log priors (log of P(category)):")
    for cls, log_prior in zip(model.classes_, model.class_log_prior_):
        print(f"    P({cls}) = {np.exp(log_prior):.4f}")
    
    return model


def evaluate_model(model, X_test_vec, y_test):
    """
    Step 5: Evaluate the model on test data.
    
    Metrics:
    - Accuracy: Overall correctness
    - Precision: How many predicted positives are actually positive
    - Recall: How many actual positives were correctly predicted
    - F1-Score: Harmonic mean of precision and recall
    - Confusion Matrix: Shows true vs predicted classifications
    """
    print("\n" + "=" * 60)
    print("STEP 5: MODEL EVALUATION")
    print("=" * 60)
    
    # Predict on test data
    y_pred = model.predict(X_test_vec)
    
    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print(f"\n  ACCURACY: {accuracy * 100:.2f}%")
    
    # Classification report
    print(f"\n  CLASSIFICATION REPORT:")
    print("-" * 60)
    report = classification_report(y_test, y_pred)
    print(report)
    
    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print(f"  CONFUSION MATRIX:")
    print(cm)
    
    return accuracy, report, cm, y_pred


def plot_confusion_matrix(cm, classes):
    """
    Step 6: Create a visual confusion matrix heatmap.
    
    The confusion matrix shows:
    - Diagonal: Correct predictions (darker = more correct)
    - Off-diagonal: Misclassifications (lighter = fewer errors)
    """
    print("\n" + "=" * 60)
    print("STEP 6: CONFUSION MATRIX VISUALIZATION")
    print("=" * 60)
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        cm, annot=True, fmt='d', cmap='Blues',
        xticklabels=classes, yticklabels=classes,
        linewidths=0.5, linecolor='gray'
    )
    plt.title('Emergency Classification - Confusion Matrix', fontsize=16, pad=20)
    plt.xlabel('Predicted Category', fontsize=12)
    plt.ylabel('Actual Category', fontsize=12)
    plt.tight_layout()
    
    # Save the plot
    plt.savefig(CONFUSION_MATRIX_PATH, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"\n  Confusion matrix saved to: {CONFUSION_MATRIX_PATH}")


def save_model(model, vectorizer):
    """
    Step 7: Save the trained model and vectorizer to disk.
    
    We use joblib for serialization because:
    - It's efficient for numpy arrays and scikit-learn objects
    - It preserves the model state completely
    - It's faster than pickle for large objects
    """
    print("\n" + "=" * 60)
    print("STEP 7: SAVING MODEL & VECTORIZER")
    print("=" * 60)
    
    joblib.dump(model, MODEL_PATH)
    print(f"  Model saved to: {MODEL_PATH}")
    
    joblib.dump(vectorizer, VECTORIZER_PATH)
    print(f"  Vectorizer saved to: {VECTORIZER_PATH}")


def predict_emergency(description, model, vectorizer):
    """
    Bonus: Predict the category for a new emergency description.
    This is the function used by the Flask app during dispatch.
    """
    vec = vectorizer.transform([description])
    category = model.predict(vec)[0]
    probabilities = model.predict_proba(vec)[0]
    
    # Create result with confidence for each class
    results = {}
    for cls, prob in zip(model.classes_, probabilities):
        results[cls] = round(prob * 100, 2)
    
    return category, results


def main():
    """Main training pipeline - runs all steps sequentially."""
    print("\n" + "=" * 70)
    print("  SMART VOLUNTEER DISPATCH - ML MODEL TRAINING")
    print("  Author: Asad | BSAI 4C | Roll No: 141 | Instructor: Rasikh Ali")
    print("=" * 70)
    
    # Step 0: Ensure dataset exists
    csv_path = generate_dataset_if_missing()
    
    # Step 1: Load data
    df = load_data(csv_path)
    
    # Step 2: Split into train/test
    X_train, X_test, y_train, y_test = split_data(df)
    
    # Step 3: TF-IDF Vectorization
    vectorizer, X_train_vec, X_test_vec = vectorize_text(X_train, X_test)
    
    # Step 4: Train classifier
    model = train_classifier(X_train_vec, y_train)
    
    # Step 5: Evaluate model
    accuracy, report, cm, y_pred = evaluate_model(model, X_test_vec, y_test)
    
    # Step 6: Plot confusion matrix
    plot_confusion_matrix(cm, model.classes_)
    
    # Step 7: Save model and vectorizer
    save_model(model, vectorizer)
    
    # Bonus: Demo prediction
    print("\n" + "=" * 60)
    print("BONUS: DEMO PREDICTION")
    print("=" * 60)
    
    test_descriptions = [
        "A building is on fire and people are trapped inside",
        "Flood water has entered homes in the village",
        "Patient needs urgent medical attention after accident",
        "Families need food packages after the disaster"
    ]
    
    for desc in test_descriptions:
        category, probs = predict_emergency(desc, model, vectorizer)
        print(f"\n  Text: '{desc}'")
        print(f"  Prediction: {category}")
        print(f"  Confidence: {max(probs.values()):.1f}%")
    
    print("\n" + "=" * 70)
    print("  MODEL TRAINING COMPLETE!")
    print(f"  Final Accuracy: {accuracy * 100:.2f}%")
    print("=" * 70 + "\n")
    
    return accuracy, report, cm


if __name__ == '__main__':
    main()
