"""
=============================================================================
  SMART VOLUNTEER DISPATCH - DATABASE INITIALIZATION SCRIPT
  Author: Asad (BSAI 4C, Roll No: 141)
  Instructor: Rasikh Ali
  
  This script creates the SQLite database with all tables, indexes,
  views, and sample data. It demonstrates every SQL concept needed
  for the viva presentation.
=============================================================================
"""

import sqlite3
import os
import shutil
from datetime import datetime, timedelta
import random

# ============================================================
# DATABASE PATH - using SQLite file-based database
# This demonstrates CREATE DATABASE concept (SQLite creates file)
# ============================================================
DB_PATH = os.path.join(os.path.dirname(__file__), 'data', 'volunteer_dispatch.db')

def get_connection():
    """Get a database connection - SQLite creates the .db file automatically."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # So we can access columns by name
    conn.execute("PRAGMA foreign_keys = ON")  # Enable FOREIGN KEY support
    return conn


def create_tables(conn):
    """
    Create all database tables demonstrating:
    - CREATE TABLE
    - PRIMARY KEY (with AUTOINCREMENT)
    - FOREIGN KEY
    - NOT NULL, UNIQUE, CHECK, DEFAULT constraints
    - CREATE INDEX
    """
    print("=" * 60)
    print("STEP 1: CREATING TABLES (DDL - Data Definition Language)")
    print("=" * 60)
    
    # -------------------------------------------------------
    # 1. emergency_categories table
    # Demonstrates: CREATE TABLE, PRIMARY KEY, NOT NULL, UNIQUE, CHECK, DEFAULT
    # -------------------------------------------------------
    print("\n[Creating: emergency_categories]")
    print("SQL Concepts: CREATE TABLE, PRIMARY KEY, NOT NULL, UNIQUE, CHECK, DEFAULT")
    
    conn.execute('''
        CREATE TABLE IF NOT EXISTS emergency_categories (
            category_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            severity_level INTEGER NOT NULL DEFAULT 5 CHECK (severity_level BETWEEN 1 AND 10),
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
    ''')
    print("  -> Table 'emergency_categories' created successfully!")

    # -------------------------------------------------------
    # 2. volunteers table
    # Demonstrates: CREATE TABLE, PRIMARY KEY AUTOINCREMENT, 
    #   FOREIGN KEY, NOT NULL, UNIQUE, CHECK, DEFAULT, CREATE INDEX
    # -------------------------------------------------------
    print("\n[Creating: volunteers]")
    print("SQL Concepts: CREATE TABLE, PRIMARY KEY AUTOINCREMENT, FOREIGN KEY,")
    print("              NOT NULL, UNIQUE, CHECK, DEFAULT")
    
    conn.execute('''
        CREATE TABLE IF NOT EXISTS volunteers (
            volunteer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            phone TEXT,
            location TEXT NOT NULL,
            skills TEXT NOT NULL DEFAULT 'general',
            availability INTEGER NOT NULL DEFAULT 1 CHECK (availability IN (0, 1)),
            preferred_category_id INTEGER,
            rating REAL DEFAULT 0.0,
            total_dispatches INTEGER DEFAULT 0,
            joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (preferred_category_id) REFERENCES emergency_categories(category_id)
        );
    ''')
    print("  -> Table 'volunteers' created successfully!")

    # -------------------------------------------------------
    # 3. skill_requirements table
    # Demonstrates: FOREIGN KEY (composite), CREATE TABLE
    # -------------------------------------------------------
    print("\n[Creating: skill_requirements]")
    print("SQL Concepts: FOREIGN KEY (composite), CREATE TABLE")
    
    conn.execute('''
        CREATE TABLE IF NOT EXISTS skill_requirements (
            requirement_id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_id INTEGER NOT NULL,
            required_skill TEXT NOT NULL,
            priority INTEGER DEFAULT 1,
            UNIQUE(category_id, required_skill),
            FOREIGN KEY (category_id) REFERENCES emergency_categories(category_id) ON DELETE CASCADE
        );
    ''')
    print("  -> Table 'skill_requirements' created successfully!")

    # -------------------------------------------------------
    # 4. emergency_logs table
    # Demonstrates: FOREIGN KEY, DEFAULT, CREATE TABLE
    # -------------------------------------------------------
    print("\n[Creating: emergency_logs]")
    print("SQL Concepts: FOREIGN KEY, DEFAULT, NOT NULL, CREATE TABLE")
    
    conn.execute('''
        CREATE TABLE IF NOT EXISTS emergency_logs (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_id INTEGER NOT NULL,
            volunteer_id INTEGER NOT NULL,
            description TEXT NOT NULL,
            location TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            dispatch_time TEXT DEFAULT CURRENT_TIMESTAMP,
            completed_time TEXT,
            FOREIGN KEY (category_id) REFERENCES emergency_categories(category_id),
            FOREIGN KEY (volunteer_id) REFERENCES volunteers(volunteer_id)
        );
    ''')
    print("  -> Table 'emergency_logs' created successfully!")

    # -------------------------------------------------------
    # 5. CREATE INDEX - Demonstrates index creation
    # -------------------------------------------------------
    print("\n[Creating INDEXES]")
    print("SQL Concept: CREATE INDEX")
    
    conn.execute('''
        CREATE INDEX IF NOT EXISTS idx_volunteer_email 
        ON volunteers(email);
    ''')
    print("  -> Index 'idx_volunteer_email' created on volunteers(email)")
    
    conn.execute('''
        CREATE INDEX IF NOT EXISTS idx_logs_status 
        ON emergency_logs(status);
    ''')
    print("  -> Index 'idx_logs_status' created on emergency_logs(status)")
    
    conn.execute('''
        CREATE INDEX IF NOT EXISTS idx_logs_category_status 
        ON emergency_logs(category_id, status);
    ''')
    print("  -> Composite index 'idx_logs_category_status' created")

    conn.commit()
    print("\n  [All tables and indexes created successfully!]")


def insert_sample_data(conn):
    """
    Insert sample data demonstrating:
    - INSERT INTO ... VALUES
    - INSERT with NULL values
    - DEFAULT values
    """
    print("\n" + "=" * 60)
    print("STEP 2: INSERTING SAMPLE DATA (DML - Data Manipulation Language)")
    print("=" * 60)
    
    # -------------------------------------------------------
    # INSERT INTO emergency_categories
    # -------------------------------------------------------
    print("\n[INSERT INTO emergency_categories]")
    print("SQL Concept: INSERT INTO ... VALUES")
    
    categories = [
        ('medical', 'Medical emergencies requiring doctors, nurses, or first aid', 9),
        ('fire', 'Fire-related emergencies requiring firefighters and rescue teams', 10),
        ('flood', 'Flood and water-related emergencies requiring rescue and relief', 8),
        ('food_distribution', 'Food shortage and distribution emergencies', 6),
    ]
    
    for cat in categories:
        conn.execute('''
            INSERT INTO emergency_categories (name, description, severity_level)
            VALUES (?, ?, ?);
        ''', cat)
        print(f"  -> Inserted category: {cat[0]} (severity: {cat[2]})")
    
    # -------------------------------------------------------
    # INSERT INTO skill_requirements
    # -------------------------------------------------------
    print("\n[INSERT INTO skill_requirements]")
    
    skills = [
        (1, 'first_aid', 1), (1, 'cpr', 1), (1, 'paramedic', 2),
        (1, 'nursing', 2), (1, 'medical_knowledge', 3),
        (2, 'firefighting', 1), (2, 'rescue', 1), (2, 'hazardous_materials', 2),
        (2, 'fire_safety', 2), (2, 'evacuation', 3),
        (3, 'swimming', 1), (3, 'rescue', 1), (3, 'boat_operation', 2),
        (3, 'first_aid', 2), (3, 'relief_work', 3),
        (4, 'food_handling', 1), (4, 'logistics', 1), (4, 'driving', 2),
        (4, 'communication', 2), (4, 'cooking', 3),
    ]
    
    for skill in skills:
        conn.execute('''
            INSERT INTO skill_requirements (category_id, required_skill, priority)
            VALUES (?, ?, ?);
        ''', skill)
    print(f"  -> Inserted {len(skills)} skill requirements")
    
    # -------------------------------------------------------
    # INSERT INTO volunteers (with various SQL concepts)
    # -------------------------------------------------------
    print("\n[INSERT INTO volunteers]")
    print("SQL Concepts: INSERT with DEFAULT, INSERT with NULL, Prepared Statements")
    
    volunteers = [
        # (name, email, phone, location, skills, availability, preferred_category, rating, dispatches)
        ('Ahmed Khan', 'ahmed@email.com', '03001234567', 'North Nazimabad', 'first_aid,cpr,paramedic', 1, 1, 4.8, 15),
        ('Fatima Ali', 'fatima@email.com', '03012345678', 'Clifton', 'nursing,first_aid,medical_knowledge', 1, 1, 4.5, 12),
        ('Hassan Raza', 'hassan@email.com', '03023456789', 'Gulshan', 'firefighting,rescue,evacuation', 1, 2, 4.9, 20),
        ('Ayesha Siddiqui', 'ayesha@email.com', '03034567890', 'DHA', 'swimming,rescue,boat_operation', 1, 3, 4.7, 18),
        ('Omar Farooq', 'omar@email.com', '03045678901', 'Bahadurabad', 'food_handling,logistics,driving', 1, 4, 4.3, 10),
        ('Zainab Malik', 'zainab@email.com', '03056789012', 'Saddar', 'first_aid,nursing,medical_knowledge', 0, 1, 4.6, 14),
        ('Bilal Ahmed', 'bilal@email.com', '03067890123', 'North Nazimabad', 'firefighting,hazardous_materials', 1, 2, 4.4, 11),
        ('Maryam Hussain', 'maryam@email.com', '03078901234', 'Clifton', 'swimming,rescue,relief_work', 1, 3, 4.2, 9),
        ('Ali Haider', 'ali@email.com', '03089012345', 'Gulshan', 'food_handling,cooking,communication', 1, 4, 4.1, 7),
        ('Sara Khan', 'sara@email.com', '03090123456', 'DHA', 'cpr,paramedic,first_aid', 1, 1, 4.8, 16),
        ('Usman Sheikh', 'usman@email.com', '03101234567', 'Bahadurabad', 'firefighting,rescue,fire_safety', 1, 2, 4.5, 13),
        ('Hira Shah', 'hira@email.com', '03112345678', 'Saddar', 'food_handling,logistics,driving', 0, 4, 3.9, 5),
        # Volunteer with NULL phone - demonstrates NULL handling
        ('Tariq Mehmood', 'tariq@email.com', None, 'Liaquatabad', 'general', 1, None, 0.0, 0),
        # New volunteer with DEFAULT values - availability, rating, dispatches use defaults
        ('Nadia Pervez', 'nadia@email.com', '03134567890', 'Korangi', 'nursing,first_aid', 1, 1, 0.0, 0),
        ('Kamran Javed', 'kamran@email.com', None, 'Malir', 'rescue,swimming,relief_work', 1, 3, 3.5, 3),
        ('Sana Tariq', 'sana@email.com', '03156789012', 'North Nazimabad', 'communication,cooking,food_handling', 1, 4, 4.0, 6),
    ]
    
    for v in volunteers:
        conn.execute('''
            INSERT INTO volunteers (name, email, phone, location, skills, 
                                   availability, preferred_category_id, rating, total_dispatches)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        ''', v)
    print(f"  -> Inserted {len(volunteers)} volunteers")
    print("  -> Note: Some volunteers have NULL phone numbers")
    print("  -> Note: Some volunteers use DEFAULT for rating and total_dispatches")
    
    # -------------------------------------------------------
    # INSERT INTO emergency_logs (sample dispatches)
    # -------------------------------------------------------
    print("\n[INSERT INTO emergency_logs]")
    print("SQL Concept: INSERT INTO ... VALUES with datetime")
    
    base_time = datetime.now()
    
    logs = [
        (1, 1, 'Heart attack patient at North Nazimabad market', 'North Nazimabad', 'completed'),
        (2, 3, 'Fire in Clifton apartment block', 'Clifton', 'completed'),
        (3, 4, 'Flooding in Gulshan after heavy rain', 'Gulshan', 'completed'),
        (4, 5, 'Food distribution needed at DHA shelter', 'DHA', 'completed'),
        (1, 2, 'Child with breathing difficulty at Saddar hospital', 'Saddar', 'completed'),
        (2, 7, 'Warehouse fire near port', 'Bahadurabad', 'dispatched'),
        (3, 8, 'River flooding in Clifton coastal area', 'Clifton', 'dispatched'),
        (4, 9, 'Emergency food supply for refugees', 'Gulshan', 'dispatched'),
        (1, 10, 'Elderly person fell down stairs', 'DHA', 'completed'),
        (2, 11, 'Forest fire near residential area', 'North Nazimabad', 'pending'),
        (1, 14, 'Pregnant woman needs emergency delivery', 'Liaquatabad', 'completed'),
        (3, 4, 'Flash flood in Korangi industrial area', 'Korangi', 'completed'),
        (4, 15, 'School meal program needs volunteers', 'North Nazimabad', 'pending'),
        (1, 1, 'Severe asthma attack patient', 'North Nazimabad', 'completed'),
        (2, 3, 'Shopping mall electrical fire', 'Bahadurabad', 'pending'),
    ]
    
    for i, log in enumerate(logs):
        dispatch_time = base_time - timedelta(hours=i*3, minutes=random.randint(0, 59))
        completed_time = None
        if log[4] == 'completed':
            completed_time = dispatch_time + timedelta(hours=random.randint(1, 3), minutes=random.randint(0, 59))
        
        conn.execute('''
            INSERT INTO emergency_logs (category_id, volunteer_id, description, location,
                                        status, dispatch_time, completed_time)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        ''', (log[0], log[1], log[2], log[3], log[4],
              dispatch_time.strftime('%Y-%m-%d %H:%M:%S'),
              completed_time.strftime('%Y-%m-%d %H:%M:%S') if completed_time else None))
    
    print(f"  -> Inserted {len(logs)} emergency log entries")
    print("  -> Some logs have NULL completed_time (still pending)")


def create_views(conn):
    """
    Create SQL Views demonstrating:
    - CREATE VIEW
    - View combining JOINs and aggregations
    """
    print("\n" + "=" * 60)
    print("STEP 3: CREATING VIEWS (Advanced SQL)")
    print("=" * 60)
    
    print("\n[Creating SQL Views]")
    print("SQL Concept: CREATE VIEW (virtual tables)")
    
    # View 1: Volunteer dispatch summary
    conn.execute('''
        CREATE VIEW IF NOT EXISTS volunteer_summary AS
        SELECT 
            v.volunteer_id,
            v.name AS volunteer_name,
            v.email,
            v.location,
            v.rating,
            v.total_dispatches,
            v.availability,
            ec.name AS preferred_category
        FROM volunteers v
        LEFT JOIN emergency_categories ec 
            ON v.preferred_category_id = ec.category_id;
    ''')
    print("  -> Created VIEW 'volunteer_summary'")
    
    # View 2: Emergency statistics
    conn.execute('''
        CREATE VIEW IF NOT EXISTS emergency_stats AS
        SELECT 
            ec.name AS category_name,
            COUNT(el.log_id) AS total_dispatches,
            SUM(CASE WHEN el.status = 'completed' THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN el.status = 'pending' THEN 1 ELSE 0 END) AS pending,
            SUM(CASE WHEN el.status = 'dispatched' THEN 1 ELSE 0 END) AS dispatched,
            AVG(v.rating) AS avg_volunteer_rating
        FROM emergency_categories ec
        LEFT JOIN emergency_logs el ON ec.category_id = el.category_id
        LEFT JOIN volunteers v ON el.volunteer_id = v.volunteer_id
        GROUP BY ec.category_id;
    ''')
    print("  -> Created VIEW 'emergency_stats'")
    
    # View 3: Available volunteers with skills
    conn.execute('''
        CREATE VIEW IF NOT EXISTS available_volunteers_detail AS
        SELECT 
            v.volunteer_id,
            v.name,
            v.location,
            v.skills,
            v.rating,
            ec.name AS preferred_category,
            COUNT(sr.requirement_id) AS matching_skills
        FROM volunteers v
        LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id
        LEFT JOIN skill_requirements sr ON ec.category_id = sr.category_id
        WHERE v.availability = 1
        GROUP BY v.volunteer_id
        ORDER BY v.rating DESC;
    ''')
    print("  -> Created VIEW 'available_volunteers_detail'")
    
    conn.commit()
    print("\n  [All views created successfully!]")


def create_stored_procedure_simulation(conn):
    """
    SQLite doesn't support stored procedures natively.
    We simulate them with Python functions that execute multiple SQL statements.
    """
    print("\n" + "=" * 60)
    print("STEP 4: STORED PROCEDURE SIMULATION")
    print("=" * 60)
    print("\nSQL Concept: Stored Procedures (simulated with Python functions)")
    print("  -> create_dispatch_procedure() - Simulates a stored procedure")
    print("     that handles dispatch in a transaction (multiple SQL statements)")
    print("  -> get_volunteer_report() - Simulates a stored procedure")
    print("     that generates a complex report using multiple queries")
    print("\n  [Stored procedures are implemented as Python functions in app.py]")


def demonstrate_advanced_sql(conn):
    """
    Print examples of advanced SQL queries that are used in the app.
    """
    print("\n" + "=" * 60)
    print("STEP 5: ADVANCED SQL CONCEPTS DEMONSTRATED")
    print("=" * 60)
    
    concepts = [
        ("SELECT DISTINCT", "SELECT DISTINCT location FROM volunteers;"),
        ("SELECT with LIMIT (TOP)", "SELECT * FROM volunteers LIMIT 5;"),
        ("WHERE with AND/OR", "SELECT * FROM volunteers WHERE availability=1 AND rating > 4.5;"),
        ("ORDER BY", "SELECT * FROM volunteers ORDER BY rating DESC;"),
        ("LIKE with Wildcards", "SELECT * FROM volunteers WHERE name LIKE 'A%';"),
        ("IN Operator", "SELECT * FROM volunteers WHERE location IN ('Clifton','DHA','Gulshan');"),
        ("BETWEEN", "SELECT * FROM volunteers WHERE rating BETWEEN 4.0 AND 4.5;"),
        ("ALIASES", "SELECT v.name AS volunteer_name, ec.name AS category FROM volunteers v LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id;"),
        ("INNER JOIN", "SELECT v.name, ec.name AS category FROM volunteers v INNER JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id;"),
        ("LEFT JOIN", "SELECT v.name, ec.name AS category FROM volunteers v LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id;"),
        ("SELF JOIN", "SELECT v1.name AS volunteer1, v2.name AS volunteer2 FROM volunteers v1 JOIN volunteers v2 ON v1.location = v2.location AND v1.volunteer_id < v2.volunteer_id;"),
        ("UNION", "SELECT name FROM volunteers WHERE rating >= 4.5 UNION SELECT name FROM volunteers WHERE total_dispatches >= 15;"),
        ("GROUP BY + HAVING", "SELECT location, COUNT(*) AS cnt FROM volunteers GROUP BY location HAVING cnt > 2;"),
        ("EXISTS", "SELECT * FROM volunteers v WHERE EXISTS (SELECT 1 FROM emergency_logs el WHERE el.volunteer_id = v.volunteer_id);"),
        ("Aggregate COUNT", "SELECT COUNT(*) AS total FROM volunteers;"),
        ("Aggregate AVG", "SELECT AVG(rating) AS avg_rating FROM volunteers;"),
        ("Aggregate SUM", "SELECT SUM(total_dispatches) AS total_dispatches FROM volunteers;"),
        ("Aggregate MIN/MAX", "SELECT MIN(rating) AS min_r, MAX(rating) AS max_r FROM volunteers;"),
        ("SQL Injection Prevention", "Using parameterized queries: cursor.execute('SELECT * FROM volunteers WHERE email=?', (email,))"),
        ("NULL Handling", "SELECT * FROM volunteers WHERE phone IS NULL;"),
        ("INSERT INTO SELECT", "CREATE TABLE backup AS SELECT * FROM volunteers;"),
        ("SELECT INTO (CREATE TABLE AS)", "CREATE TABLE active_volunteers AS SELECT * FROM volunteers WHERE availability=1;"),
        ("UNION ALL", "SELECT 'volunteer' AS source, COUNT(*) FROM volunteers UNION ALL SELECT 'log', COUNT(*) FROM emergency_logs;"),
    ]
    
    for concept, query in concepts:
        print(f"\n  [{concept}]")
        print(f"    {query}")


def backup_database(conn):
    """
    Demonstrates: BACKUP DATABASE
    Creates a backup copy of the .db file
    """
    print("\n" + "=" * 60)
    print("STEP 6: DATABASE BACKUP")
    print("=" * 60)
    
    backup_dir = os.path.join(os.path.dirname(__file__), 'data')
    backup_path = os.path.join(backup_dir, 'volunteer_dispatch_backup.db')
    
    if os.path.exists(backup_path):
        os.remove(backup_path)
    
    shutil.copy2(DB_PATH, backup_path)
    print(f"\n  -> Database backed up to: {backup_path}")
    print("  -> SQL Concept: BACKUP DATABASE (file copy for SQLite)")


def main():
    """Main function to initialize the entire database."""
    print("\n" + "=" * 70)
    print("  SMART VOLUNTEER DISPATCH - DATABASE INITIALIZATION")
    print("  Author: Asad | BSAI 4C | Roll No: 141 | Instructor: Rasikh Ali")
    print("=" * 70)
    
    # Remove existing database to start fresh
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
        print(f"\n  [Removed existing database: {DB_PATH}]")
    
    # Create data directory if it doesn't exist
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    conn = get_connection()
    
    try:
        # Step 1: Create all tables
        create_tables(conn)
        
        # Step 2: Insert sample data
        insert_sample_data(conn)
        
        # Step 3: Create views
        create_views(conn)
        
        # Step 4: Stored procedure simulation
        create_stored_procedure_simulation(conn)
        
        # Step 5: Show advanced SQL concepts
        demonstrate_advanced_sql(conn)
        
        # Step 6: Backup database
        backup_database(conn)
        
        print("\n" + "=" * 70)
        print("  DATABASE INITIALIZATION COMPLETE!")
        print(f"  Database location: {DB_PATH}")
        print("=" * 70 + "\n")
        
    except Exception as e:
        print(f"\n  ERROR: {e}")
        raise
    finally:
        conn.close()


if __name__ == '__main__':
    main()
