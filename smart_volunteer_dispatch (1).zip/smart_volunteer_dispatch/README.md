# Smart Volunteer Dispatch with SQL & ML

## Student Information
- **Name:** Asad
- **Class:** BSAI 4C
- **Roll Number:** 141
- **Instructor:** Rasikh Ali

---

## What This Project Does (Simple Explanation)

This project is a **web application** (a website) that helps dispatch volunteers during emergencies. When someone reports an emergency (like a fire, flood, medical emergency, or food shortage), the system:

1. **Reads the emergency description** (text written by the user)
2. **Uses Machine Learning (AI)** to figure out what type of emergency it is (medical, fire, flood, or food distribution)
3. **Uses SQL (Database queries)** to find the best available volunteer for that type of emergency
4. **Shows everything on a beautiful website** built with Flask (Python web framework)

Think of it like: **You type "There is a fire!" → AI says "This is a fire emergency" → Database finds "Hassan Raza is a firefighter, he's available, rating 4.9/5" → Hassan gets dispatched!**

---

## Technologies Used

| Technology | What It Does | Where In Project |
|---|---|---|
| **Python** | Programming language | Everything is written in Python |
| **Flask** | Web framework (makes websites in Python) | `app.py` - the main application |
| **SQLite** | Lightweight database (stores data in a file) | `data/volunteer_dispatch.db` |
| **SQL** | Language to talk to the database | Throughout `app.py` and `init_db.py` |
| **scikit-learn** | Machine Learning library | `train_model.py` - trains the AI model |
| **pandas** | Data manipulation library | `train_model.py` - loads and processes CSV |
| **joblib** | Saves trained models to files | Saves `.pkl` files in `models/` folder |
| **matplotlib/seaborn** | Chart and visualization libraries | Creates confusion matrix plot |
| **Jinja2** | Template engine (generates HTML) | All files in `templates/` folder |
| **HTML/CSS** | Web page structure and styling | `templates/` and `static/style.css` |

---

## Project Structure (Every File Explained)

```
smart_volunteer_dispatch/
│
├── app.py                     # THE MAIN APPLICATION - Flask server with all routes
├── init_db.py                 # Creates the database, tables, and inserts sample data
├── train_model.py             # Trains the Machine Learning model (standalone script)
├── Train_Model.ipynb          # Jupyter Notebook version of the training (with outputs)
├── generate_notebook.py       # Helper script to create the notebook
├── requirements.txt           # List of Python packages needed
│
├── models/                    # Trained ML model files
│   ├── emergency_model.pkl    # The trained Naive Bayes classifier
│   └── vectorizer.pkl         # The TF-IDF text vectorizer
│
├── data/                      # Database and dataset
│   ├── emergency_data.csv     # 78 emergency descriptions with categories
│   └── volunteer_dispatch.db  # SQLite database (created by init_db.py)
│
├── templates/                 # HTML pages (Jinja2 templates)
│   ├── base.html              # Common layout (navbar, footer) used by all pages
│   ├── index.html             # Home page - Emergency Dispatch Center
│   ├── volunteers.html        # Volunteer Management (Add/Edit/Delete/Search)
│   ├── sql_demos.html         # SQL Concept Demonstrations (36 buttons!)
│   ├── model.html             # ML Model Training & Evaluation
│   └── logs.html              # Emergency Logs with statistics
│
├── static/                    # Static files (CSS, images)
│   ├── style.css              # Complete stylesheet for the website
│   └── plots/                 # Generated plots
│       └── confusion_matrix.png  # Confusion matrix from ML training
│
└── README.md                  # This file!
```

---

## STEP-BY-STEP SETUP INSTRUCTIONS

### Prerequisites
You need **Python 3.8 or higher** installed on your computer.

### Step 1: Download/Extract the Project
Extract the project folder to your computer. Note the folder path (e.g., `C:\Users\YourName\Desktop\smart_volunteer_dispatch` or `/home/user/smart_volunteer_dispatch`).

### Step 2: Open Terminal/Command Prompt
- **Windows:** Press Win+R, type `cmd`, press Enter
- **Mac:** Press Cmd+Space, type `terminal`, press Enter
- **Linux:** Press Ctrl+Alt+T

### Step 3: Navigate to the Project Folder
```
cd path/to/smart_volunteer_dispatch
```
For example:
```
cd C:\Users\YourName\Desktop\smart_volunteer_dispatch
```

### Step 4: Install Required Packages
```
pip install -r requirements.txt
```
This installs: flask, pandas, scikit-learn, joblib, matplotlib, seaborn, jupyter, notebook

> **If you get an error about "externally managed environment":**
> Use: `pip install -r requirements.txt --break-system-packages`
> Or create a virtual environment first (recommended):
> ```
> python -m venv venv
> venv\Scripts\activate      (Windows)
> source venv/bin/activate   (Mac/Linux)
> pip install -r requirements.txt
> ```

### Step 5: Run the Application
```
python app.py
```
You will see output like:
```
  SMART VOLUNTEER DISPATCH
  By: Asad | BSAI 4C | Roll #141
  Starting Flask server...
  Open your browser: http://127.0.0.1:5000
```

### Step 6: Open Your Browser
Go to: **http://127.0.0.1:5000**

That's it! The app should open and work immediately because the database and model are pre-built.

### Step 7: Stop the Server
Press **Ctrl+C** in the terminal to stop the server.

---

## ALL SQL CONCEPTS DEMONSTRATED

This project covers **EVERY SQL concept** required for your viva. Here's where to find each one:

### 1. DDL (Data Definition Language)

| Concept | Description | Where to Find |
|---|---|---|
| **CREATE TABLE** | Creating database tables | `init_db.py` lines 53-130, or click "All Constraints" in SQL Demos |
| **ALTER TABLE** | Modifying table structure | SQL Demos -> click "ALTER TABLE" button |
| **DROP TABLE** | Deleting a table permanently | SQL Demos -> click "DROP TABLE" button |
| **CREATE INDEX** | Creating indexes for faster queries | `init_db.py` lines 139-155, SQL Demos -> "CREATE INDEX" |
| **AUTOINCREMENT** | Auto-generating IDs | `init_db.py` - every table has `INTEGER PRIMARY KEY AUTOINCREMENT` |
| **CREATE VIEW** | Creating virtual tables | `init_db.py` lines 314-365, SQL Demos -> "SQL VIEW" |

### 2. DML (Data Manipulation Language)

| Concept | Description | Where to Find |
|---|---|---|
| **INSERT** | Adding new data | Volunteers page -> Add form; `init_db.py` insert_sample_data() |
| **UPDATE** | Modifying existing data | Volunteers page -> Edit a volunteer |
| **DELETE** | Removing data | Volunteers page -> Delete button on any volunteer |
| **SELECT** | Reading data | Everywhere! Every page runs SELECT queries |
| **SELECT DISTINCT** | Get unique values | SQL Demos -> "SELECT DISTINCT" button |
| **LIMIT** | Restrict number of results | Volunteers page -> Show dropdown; SQL Demos -> "LIMIT" |
| **INSERT INTO SELECT** | Copy data between tables | SQL Demos -> "INSERT INTO SELECT" button |
| **SELECT INTO** | Create table from query results | SQL Demos -> "CREATE TABLE AS SELECT" button |

### 3. Constraints

| Concept | Description | Where to Find |
|---|---|---|
| **NOT NULL** | Column cannot be empty | `init_db.py` - `name TEXT NOT NULL` in volunteers table |
| **UNIQUE** | No duplicate values | `init_db.py` - `email TEXT NOT NULL UNIQUE` |
| **PRIMARY KEY** | Unique row identifier | Every table has `INTEGER PRIMARY KEY AUTOINCREMENT` |
| **FOREIGN KEY** | Links to another table's primary key | Volunteers table references emergency_categories |
| **CHECK** | Value must satisfy condition | `severity_level INTEGER CHECK (severity_level BETWEEN 1 AND 10)` |
| **DEFAULT** | Auto-fill if no value given | `rating REAL DEFAULT 0.0`, `availability DEFAULT 1` |

### 4. Query Clauses

| Concept | Description | Where to Find |
|---|---|---|
| **WHERE** | Filter rows based on condition | Volunteers page -> search; SQL Demos -> "WHERE + AND/OR/NOT" |
| **AND / OR / NOT** | Combine multiple conditions | SQL Demos -> "WHERE + AND/OR/NOT" button |
| **ORDER BY** | Sort results | Volunteers page -> Sort dropdown; SQL Demos -> "ORDER BY" |
| **LIKE** | Pattern matching with wildcards | SQL Demos -> "LIKE + Wildcards" button |
| **Wildcards (%  _)** | `%` matches any chars, `_` matches one | SQL Demos -> "LIKE + Wildcards" (shows both) |
| **IN** | Match against a list of values | SQL Demos -> "IN Operator" button |
| **BETWEEN** | Range check (inclusive) | SQL Demos -> "BETWEEN" button |
| **ALIASES (AS)** | Temporary names for columns/tables | SQL Demos -> "ALIASES" button |
| **IS NULL / IS NOT NULL** | Check for NULL values | SQL Demos -> "NULL Handling" button |

### 5. JOINs

| Concept | Description | Where to Find |
|---|---|---|
| **INNER JOIN** | Only matching rows from both tables | SQL Demos -> "INNER JOIN" button |
| **LEFT JOIN** | All rows from left, matched from right | SQL Demos -> "LEFT JOIN" button |
| **RIGHT JOIN** | All rows from right, matched from left (simulated) | SQL Demos -> "RIGHT JOIN (Simulated)" |
| **FULL OUTER JOIN** | All rows from both tables (simulated with UNION) | SQL Demos -> "FULL OUTER JOIN" button |
| **SELF JOIN** | Table joined to itself | SQL Demos -> "SELF JOIN" button |

### 6. Set Operations

| Concept | Description | Where to Find |
|---|---|---|
| **UNION** | Combine results, remove duplicates | SQL Demos -> "UNION" button |
| **UNION ALL** | Combine results, keep duplicates | SQL Demos -> "UNION ALL" button |

### 7. Grouping and Aggregation

| Concept | Description | Where to Find |
|---|---|---|
| **GROUP BY** | Group rows with same values | SQL Demos -> "GROUP BY + HAVING"; Logs page statistics |
| **HAVING** | Filter groups (like WHERE for groups) | SQL Demos -> "GROUP BY + HAVING" |
| **COUNT()** | Count rows | SQL Demos -> "COUNT()" button |
| **SUM()** | Total of values | SQL Demos -> "SUM() + AVG()" button |
| **AVG()** | Average of values | SQL Demos -> "SUM() + AVG()" button |
| **MIN()** | Minimum value | SQL Demos -> "MIN() + MAX()" button |
| **MAX()** | Maximum value | SQL Demos -> "MIN() + MAX()" button |

### 8. Advanced SQL

| Concept | Description | Where to Find |
|---|---|---|
| **EXISTS** | Check if subquery returns rows | SQL Demos -> "EXISTS" button |
| **ANY / ALL** | Compare with subquery results | SQL Demos -> "ANY / ALL" button |
| **SUBQUERY** | Query inside another query | SQL Demos -> "SUBQUERY" button |
| **CASE WHEN** | Conditional logic in SQL (like IF-ELSE) | SQL Demos -> "CASE WHEN" button |
| **SQL Views** | Virtual tables from stored queries | SQL Demos -> "SQL VIEW" button |
| **Stored Procedures** | Simulated with Python functions | SQL Demos -> "Stored Procedure" button |
| **SQL Injection Prevention** | Using parameterized queries | SQL Demos -> "SQL Injection Prevention" |
| **SQL Comments** | Single-line (`--`) and multi-line (`/* */`) | SQL Demos -> "SQL Comments" button |
| **BACKUP DATABASE** | Copy database file | SQL Demos -> "BACKUP DATABASE" button |

---

## How the Machine Learning Model Works

### What is the Problem?
When someone reports an emergency, we need to automatically classify it into one of 4 categories:
- **Medical** - heart attacks, injuries, breathing problems
- **Fire** - building fires, forest fires, explosions
- **Flood** - river flooding, heavy rain, tsunami
- **Food Distribution** - hunger, food shortage, relief distribution

### How Does It Work? (Step by Step)

1. **Dataset:** We have 78 emergency descriptions (text) labeled with their categories. This is in `data/emergency_data.csv`.

2. **TF-IDF Vectorization:** Computers can't read text directly. We convert text to numbers using TF-IDF:
   - **TF (Term Frequency):** How often does a word appear in the description?
   - **IDF (Inverse Document Frequency):** How rare is this word across ALL descriptions?
   - Words like "the", "is", "a" get low scores (they're everywhere)
   - Words like "fire", "flood", "heart" get high scores (they're rare and informative)
   - Result: Each description becomes a vector of 772 numbers

3. **Train/Test Split:** We split the data:
   - 80% for training (62 descriptions) - the model learns from these
   - 20% for testing (16 descriptions) - we test how well it learned

4. **Multinomial Naive Bayes:** This is our classifier:
   - Based on **Bayes' Theorem**: P(category|text) = P(text|category) × P(category) / P(text)
   - "Naive" because it assumes each word is independent (simplification)
   - Works great for text classification!
   - **Laplace Smoothing (alpha=1.0):** Prevents zero probability for unseen words

5. **Evaluation:**
   - **Accuracy:** 68.75% of test descriptions were classified correctly
   - **Precision:** Out of all predicted as X, how many were actually X?
   - **Recall:** Out of all actual X, how many did we correctly predict?
   - **F1-Score:** Balance between precision and recall
   - **Confusion Matrix:** Visual table showing actual vs predicted categories

### How to Train the Model
The model is **already pre-trained** and ready to use! But if you want to retrain:
1. Open the website -> click "ML Model" in the navbar
2. Click the green "Train Model Now" button
3. Wait a few seconds for the new accuracy, classification report, and confusion matrix to appear

Or run from terminal:
```
python train_model.py
```

Or open the Jupyter Notebook:
```
jupyter notebook Train_Model.ipynb
```

---

## Description of All Pages

### 1. Home (Emergency Dispatch Center) - `index.html`
**URL:** http://127.0.0.1:5000/

This is the main page. At the top you see 4 statistics cards showing:
- Total Volunteers, Available Volunteers, Total Dispatches, ML Accuracy

**To dispatch an emergency:**
1. Type an emergency description in the text box (e.g., "There is a fire in the building!")
2. Enter a location (e.g., "Clifton, Karachi")
3. Click "Dispatch Emergency"
4. The ML model classifies the emergency type and shows confidence bars
5. The SQL query that found the best volunteer is displayed
6. The matched volunteer's details are shown

You can also click "Generate with AI" to auto-fill the description using the Gemini API.

**Recent dispatches** are shown in a table at the bottom.

### 2. Volunteer Management - `volunteers.html`
**URL:** http://127.0.0.1:5000/volunteers

This page demonstrates **CRUD operations** (Create, Read, Update, Delete):

**Add Volunteer:**
- Fill the form at the top and click "Add Volunteer"
- Uses SQL INSERT statement

**Edit Volunteer:**
- Click the blue "Edit" button next to any volunteer
- The form fills with their data, modify and click "Update"
- Uses SQL UPDATE statement

**Delete Volunteer:**
- Click the red "Delete" button (with confirmation dialog)
- Uses SQL DELETE statement

**Search & Filter:**
- **Name Search:** Uses SQL LIKE '%keyword%' (wildcard pattern matching)
- **Location Filter:** Uses SQL WHERE with IN operator concept
- **Sort:** Uses SQL ORDER BY (by name, rating, or dispatches)
- **Limit:** Uses SQL LIMIT to show 5, 10, or all results
- The exact SQL query used is shown below the filters

### 3. SQL Demos - `sql_demos.html`
**URL:** http://127.0.0.1:5000/sql_demos

This is the **most important page for your viva**! It has **36 buttons**, one for each SQL concept.

**How to use:**
1. Click any SQL concept button (e.g., "INNER JOIN")
2. The page shows the SQL query that was executed
3. The results appear in a table on the right
4. An explanation of the concept is shown below the query

**All 36 SQL concepts covered:**
SELECT DISTINCT, LIMIT, WHERE+AND/OR/NOT, LIKE+Wildcards, IN, BETWEEN, ORDER BY, ALIASES, INNER JOIN, LEFT JOIN, RIGHT JOIN, FULL OUTER JOIN, SELF JOIN, UNION, UNION ALL, GROUP BY+HAVING, EXISTS, ANY/ALL, COUNT, SUM+AVG, MIN+MAX, NULL Handling, INSERT INTO SELECT, CREATE TABLE AS SELECT, SQL VIEW, SUBQUERY, CASE WHEN, SQL Injection Prevention, SQL Comments, BACKUP DATABASE, ALTER TABLE, DROP TABLE, CREATE INDEX, All Constraints, Stored Procedure, Comprehensive Aggregate

### 4. ML Model Training - `model.html`
**URL:** http://127.0.0.1:5000/model

This page shows everything about the Machine Learning model:

- **Stats Cards:** Model accuracy, dataset size, TF-IDF features, number of categories
- **How It Works:** Detailed explanation of the ML pipeline and key concepts
- **Train Button:** Click to retrain the model and see updated results
- **Classification Report:** Shows precision, recall, F1-score per category
- **Confusion Matrix:** Visual heatmap showing classification performance
- **Live Prediction Demo:** Type any emergency description and see the model classify it in real-time with confidence bars

### 5. Emergency Logs - `logs.html`
**URL:** http://127.0.0.1:5000/logs

Shows the history of all emergency dispatches:

- **Stats Cards:** Total dispatches, completed, pending, in-progress
- **Aggregate Statistics:** Dispatch counts per category with average volunteer ratings (uses GROUP BY + Aggregates)
- **Filter:** Filter logs by category and status (uses WHERE clause)
- **All Logs Table:** Complete dispatch history with duration calculation
- **Top Volunteers:** Ranking by number of dispatches (uses ORDER BY + LIMIT)
- **SQL queries are shown** for the aggregate stats, filters, and rankings

---

## Database Schema (Tables)

### Table: emergency_categories
| Column | Type | Constraints | Description |
|---|---|---|---|
| category_id | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique category ID |
| name | TEXT | NOT NULL, UNIQUE | Category name (medical, fire, flood, food_distribution) |
| description | TEXT | (nullable) | Category description |
| severity_level | INTEGER | NOT NULL, DEFAULT 5, CHECK(1-10) | Emergency severity |
| created_at | TEXT | DEFAULT CURRENT_TIMESTAMP | Creation timestamp |

### Table: volunteers
| Column | Type | Constraints | Description |
|---|---|---|---|
| volunteer_id | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique volunteer ID |
| name | TEXT | NOT NULL | Full name |
| email | TEXT | NOT NULL, UNIQUE | Email address |
| phone | TEXT | (nullable) | Phone number |
| location | TEXT | NOT NULL | Location/area |
| skills | TEXT | NOT NULL, DEFAULT 'general' | Skills (comma-separated) |
| availability | INTEGER | NOT NULL, DEFAULT 1, CHECK(0,1) | 1=available, 0=busy |
| preferred_category_id | INTEGER | FOREIGN KEY | References emergency_categories |
| rating | REAL | DEFAULT 0.0 | Performance rating |
| total_dispatches | INTEGER | DEFAULT 0 | Number of dispatches |
| joined_at | TEXT | DEFAULT CURRENT_TIMESTAMP | Join timestamp |

### Table: skill_requirements
| Column | Type | Constraints | Description |
|---|---|---|---|
| requirement_id | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique ID |
| category_id | INTEGER | NOT NULL, FOREIGN KEY | References emergency_categories |
| required_skill | TEXT | NOT NULL | Skill name |
| priority | INTEGER | DEFAULT 1 | 1=high, 2=medium, 3=low |

### Table: emergency_logs
| Column | Type | Constraints | Description |
|---|---|---|---|
| log_id | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique log ID |
| category_id | INTEGER | NOT NULL, FOREIGN KEY | References emergency_categories |
| volunteer_id | INTEGER | NOT NULL, FOREIGN KEY | References volunteers |
| description | TEXT | NOT NULL | Emergency description |
| location | TEXT | NOT NULL | Emergency location |
| status | TEXT | DEFAULT 'pending' | pending/dispatched/completed |
| dispatch_time | TEXT | DEFAULT CURRENT_TIMESTAMP | When dispatched |
| completed_time | TEXT | (nullable) | When completed |

### Views (Virtual Tables)
- **volunteer_summary:** Volunteer details with category names (LEFT JOIN)
- **emergency_stats:** Dispatch statistics per category (GROUP BY + Aggregates)
- **available_volunteers_detail:** Available volunteers with matching skill counts

---

## Viva Preparation Tips

1. **Know the ML Pipeline:** Load data → Split → Vectorize (TF-IDF) → Train (Naive Bayes) → Evaluate → Save

2. **Know Every SQL Concept:** Go through ALL 36 buttons on the SQL Demos page. Each one shows the query and results.

3. **Be Ready to Explain:**
   - What is TF-IDF and why we use it
   - What is Naive Bayes and Bayes' theorem
   - What is a confusion matrix
   - Difference between INNER JOIN and LEFT JOIN
   - What is GROUP BY and HAVING
   - How SQL injection is prevented (parameterized queries)

4. **Key Numbers to Remember:**
   - Dataset: 78 samples, 4 categories
   - Train/Test split: 80/20 (62 train, 16 test)
   - TF-IDF features: 772
   - Model accuracy: ~69%
   - Model type: Multinomial Naive Bayes

5. **Run the App Before the Viva:** Make sure everything works! Open each page, click each button.

---

## Troubleshooting

### "ModuleNotFoundError: No module named 'flask'"
Run: `pip install -r requirements.txt`

### Database not working
Delete `data/volunteer_dispatch.db` and run: `python init_db.py`

### Model not working
Delete `models/emergency_model.pkl` and `models/vectorizer.pkl`, then run: `python train_model.py`

### Port already in use
Change the port in `app.py` at the bottom: `app.run(debug=True, port=5001)`

---

## Optional: Using AI APIs

The project includes integration with:
- **Google Gemini API** - For generating emergency descriptions
- **Groq API** - For verifying classifications

These are optional. The system works perfectly without them (fallback is built in). API keys are included in `app.py` in the `/generate_ai` route.

---

**Built with Python, Flask, SQLite, and scikit-learn**
**By Asad | BSAI 4C | Roll #141 | Instructor: Rasikh Ali**
