"""
=============================================================================
  SMART VOLUNTEER DISPATCH - Main Flask Application
  Author: Asad (BSAI 4C, Roll No: 141)
  Instructor: Rasikh Ali
  
  This Flask app combines SQL database operations and Machine Learning
  into a single web application for emergency volunteer dispatch.
  
  Pages:
    1. Home (index) - Emergency Dispatch with ML classification + SQL matching
    2. Volunteers - CRUD operations for volunteer management
    3. SQL Demos - Interactive SQL concept demonstrations
    4. Model Training - ML model training and evaluation display
    5. Emergency Logs - Dispatch history with aggregate statistics
=============================================================================
"""

import os
import sqlite3
import shutil
import joblib
from datetime import datetime
from flask import (Flask, render_template, request, redirect, url_for,
                   flash, jsonify, session)
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

# ============================================================
# FLASK APP SETUP
# ============================================================
app = Flask(__name__)
app.secret_key = 'smart_volunteer_dispatch_secret_key_2024'

# ============================================================
# PATHS
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'data', 'volunteer_dispatch.db')
MODEL_PATH = os.path.join(BASE_DIR, 'models', 'emergency_model.pkl')
VECTORIZER_PATH = os.path.join(BASE_DIR, 'models', 'vectorizer.pkl')
PLOT_DIR = os.path.join(BASE_DIR, 'static', 'plots')
CSV_PATH = os.path.join(BASE_DIR, 'data', 'emergency_data.csv')
CONFUSION_MATRIX_PATH = os.path.join(PLOT_DIR, 'confusion_matrix.png')

os.makedirs(PLOT_DIR, exist_ok=True)


# ============================================================
# DATABASE HELPER FUNCTIONS
# ============================================================
def get_db():
    """
    Get a database connection with row_factory enabled.
    This lets us access columns by name (like dict).
    SQL Concept: Connection to SQLite database
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def dict_from_row(row):
    """Convert a sqlite3.Row to a dictionary."""
    if row is None:
        return None
    return dict(row)


def rows_to_dicts(rows):
    """Convert a list of sqlite3.Row objects to list of dicts."""
    return [dict(row) for row in rows]


# ============================================================
# ML MODEL HELPERS
# ============================================================
def load_model():
    """
    Load the trained ML model and vectorizer from disk.
    Returns (model, vectorizer) tuple or (None, None) if not found.
    """
    try:
        model = joblib.load(MODEL_PATH)
        vectorizer = joblib.load(VECTORIZER_PATH)
        return model, vectorizer
    except FileNotFoundError:
        return None, None


def train_ml_model():
    """
    Full ML training pipeline:
    1. Load dataset from CSV
    2. Train/Test split (80/20, stratified)
    3. TF-IDF vectorization (max 5000 features, English stop words)
    4. Train Multinomial Naive Bayes classifier
    5. Calculate accuracy, classification report, confusion matrix
    6. Save confusion matrix as PNG
    7. Save model and vectorizer as .pkl files
    Returns: (accuracy, classification_report_string, confusion_matrix_array)
    """
    # Step 1: Load data
    df = pd.read_csv(CSV_PATH)

    # Step 2: Split data
    X = df['description']
    y = df['category']
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Step 3: TF-IDF Vectorization
    vectorizer = TfidfVectorizer(
        max_features=5000,
        stop_words='english',
        ngram_range=(1, 2),
        lowercase=True
    )
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    # Step 4: Train classifier
    model = MultinomialNB(alpha=1.0)
    model.fit(X_train_vec, y_train)

    # Step 5: Evaluate
    y_pred = model.predict(X_test_vec)
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    # Step 6: Plot confusion matrix
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        cm, annot=True, fmt='d', cmap='Blues',
        xticklabels=model.classes_, yticklabels=model.classes_,
        linewidths=0.5, linecolor='gray'
    )
    plt.title('Emergency Classification - Confusion Matrix', fontsize=16, pad=20)
    plt.xlabel('Predicted Category', fontsize=12)
    plt.ylabel('Actual Category', fontsize=12)
    plt.tight_layout()
    plt.savefig(CONFUSION_MATRIX_PATH, dpi=150, bbox_inches='tight')
    plt.close()

    # Step 7: Save model
    joblib.dump(model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)

    return accuracy, report, cm


def predict_emergency(description):
    """
    Classify an emergency description using the trained ML model.
    Returns: (predicted_category, confidence_dict) or (None, None)
    """
    model, vectorizer = load_model()
    if model is None or vectorizer is None:
        return None, None

    vec = vectorizer.transform([description])
    category = model.predict(vec)[0]
    probabilities = model.predict_proba(vec)[0]

    confidence = {}
    for cls, prob in zip(model.classes_, probabilities):
        confidence[cls] = round(prob * 100, 2)

    return category, confidence


# ============================================================
# ROUTE 1: HOME / DISPATCH PAGE
# ============================================================
@app.route('/', methods=['GET', 'POST'])
def index():
    """
    Home page - Emergency Dispatch Center.
    GET: Show the dispatch form and recent logs.
    POST: Classify emergency with ML, find best volunteer with SQL JOIN.
    """
    conn = get_db()

    # Get dashboard stats
    total_volunteers = conn.execute("SELECT COUNT(*) FROM volunteers").fetchone()[0]
    available = conn.execute("SELECT COUNT(*) FROM volunteers WHERE availability=1").fetchone()[0]
    total_dispatches = conn.execute("SELECT COUNT(*) FROM emergency_logs").fetchone()[0]

    # Try to get ML accuracy
    model, _ = load_model()
    ml_accuracy = 0.0
    if model:
        ml_accuracy = 0.69  # approximate from training

    stats = {
        'total_volunteers': total_volunteers,
        'available_volunteers': available,
        'total_dispatches': total_dispatches,
        'ml_accuracy': ml_accuracy
    }

    # Get recent dispatch logs with JOIN
    recent_logs = rows_to_dicts(conn.execute('''
        SELECT el.dispatch_time, ec.name AS category_name, el.description,
               el.location, v.name AS volunteer_name, el.status
        FROM emergency_logs el
        INNER JOIN emergency_categories ec ON el.category_id = ec.category_id
        INNER JOIN volunteers v ON el.volunteer_id = v.volunteer_id
        ORDER BY el.dispatch_time DESC
        LIMIT 10
    ''').fetchall())

    dispatch_result = None
    description = ''
    location = ''

    if request.method == 'POST':
        description = request.form.get('description', '').strip()
        location = request.form.get('location', '').strip()

        if description and location:
            # Step 1: ML Classification
            category, confidence = predict_emergency(description)

            if category:
                # Step 2: Find best matching volunteer using SQL JOIN
                # This is the core SQL + ML integration!
                query = f'''
SELECT v.volunteer_id, v.name, v.email, v.location, v.skills,
       v.rating, v.total_dispatches, v.availability,
       ec.name AS category_name
FROM volunteers v
LEFT JOIN emergency_categories ec
    ON v.preferred_category_id = ec.category_id
WHERE v.availability = 1
ORDER BY
    CASE WHEN ec.name = '{category}' THEN 0 ELSE 1 END,
    v.rating DESC,
    v.total_dispatches DESC
LIMIT 1;
'''
                volunteer = conn.execute(query).fetchone()

                dispatch_result = {
                    'category': category,
                    'confidence': confidence,
                    'sql_query': query,
                    'volunteer': dict_from_row(volunteer) if volunteer else None
                }

                # Step 3: Log the dispatch (INSERT)
                # Get category_id
                cat_row = conn.execute(
                    "SELECT category_id FROM emergency_categories WHERE name=?", (category,)
                ).fetchone()

                if cat_row and volunteer:
                    conn.execute('''
                        INSERT INTO emergency_logs (category_id, volunteer_id, description, location, status)
                        VALUES (?, ?, ?, ?, 'dispatched')
                    ''', (cat_row['category_id'], volunteer['volunteer_id'], description, location))
                    conn.commit()
                    flash('Emergency dispatched successfully!', 'success')
            else:
                flash('ML model not trained yet. Please go to Model Training page.', 'danger')

    conn.close()
    return render_template('index.html', stats=stats, dispatch_result=dispatch_result,
                           recent_logs=recent_logs, description=description, location=location)


# ============================================================
# AI GENERATION ENDPOINT
# ============================================================
@app.route('/generate_ai', methods=['POST'])
def generate_ai():
    """
    Use Gemini API (or fallback) to generate an emergency description.
    Demonstrates optional AI API integration.
    """
    try:
        import google.generativeai as genai
        genai.configure(api_key='AIzaSyB5QqFtEm-jrOciZZS_C5dD9hCaPq2eINY')
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(
            'Generate a single realistic emergency description (one sentence) '
            'and a location in Karachi, Pakistan. Format as JSON: '
            '{"description": "...", "location": "..."}'
        )
        import json
        data = json.loads(response.text)
        return jsonify(data)
    except Exception:
        # Fallback - generate a random description
        import random
        descriptions = [
            "A building is on fire and people are trapped inside",
            "Flood water has entered homes in the low-lying area",
            "A patient collapsed due to heart attack and needs CPR",
            "Families are starving after the earthquake and need food",
            "A child is having severe breathing difficulty",
            "Forest fire is spreading rapidly toward the residential area",
            "Heavy monsoon has caused flash flooding in the neighborhood",
            "The refugee camp is running out of food supplies"
        ]
        locations = ["Clifton, Karachi", "North Nazimabad", "Gulshan-e-Iqbal", "DHA Phase 5",
                     "Saddar, Karachi", "Bahadurabad", "Korangi", "Malir"]
        return jsonify({
            'description': random.choice(descriptions),
            'location': random.choice(locations)
        })


# ============================================================
# ROUTE 2: VOLUNTEER MANAGEMENT
# ============================================================
@app.route('/volunteers', methods=['GET', 'POST'])
def volunteers():
    """
    Volunteer Management page - Full CRUD operations.
    Demonstrates: INSERT, SELECT, UPDATE, DELETE, WHERE, LIKE,
                 ORDER BY, LIMIT, IN, JOIN, SELECT DISTINCT
    """
    conn = get_db()

    # Handle POST - Add or Update volunteer
    if request.method == 'POST':
        vid = request.form.get('volunteer_id')
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip() or None  # NULL if empty
        location = request.form.get('location', '').strip()
        skills = request.form.get('skills', '').strip()
        pref_cat = request.form.get('preferred_category_id') or None  # NULL if empty
        availability = int(request.form.get('availability', 1))

        if vid:
            # UPDATE existing volunteer
            # SQL Concept: UPDATE with SET, WHERE
            conn.execute('''
                UPDATE volunteers SET name=?, email=?, phone=?, location=?,
                    skills=?, preferred_category_id=?, availability=?
                WHERE volunteer_id=?
            ''', (name, email, phone, location, skills, pref_cat, availability, vid))
            conn.commit()
            flash(f'Volunteer "{name}" updated successfully! (UPDATE statement executed)', 'success')
            return redirect(url_for('volunteers'))
        else:
            # INSERT new volunteer
            # SQL Concept: INSERT INTO ... VALUES with Prepared Statement
            try:
                conn.execute('''
                    INSERT INTO volunteers (name, email, phone, location, skills,
                                           preferred_category_id, availability)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (name, email, phone, location, skills, pref_cat, availability))
                conn.commit()
                flash(f'Volunteer "{name}" added successfully! (INSERT statement executed)', 'success')
                return redirect(url_for('volunteers'))
            except sqlite3.IntegrityError as e:
                if 'UNIQUE' in str(e):
                    flash('Error: A volunteer with this email already exists! (UNIQUE constraint violation)', 'danger')
                else:
                    flash(f'Database error: {e}', 'danger')

    # Handle GET with filters
    search_term = request.args.get('search', '').strip()
    selected_location = request.args.get('location', '').strip()
    sort_by = request.args.get('sort', 'name_asc')
    show_limit = request.args.get('limit', 'all')
    edit_id = request.args.get('edit_id', type=int)

    # Get all categories for the form dropdown
    categories = rows_to_dicts(conn.execute(
        "SELECT * FROM emergency_categories ORDER BY name"
    ).fetchall())

    # Get distinct locations (SELECT DISTINCT)
    # SQL Concept: SELECT DISTINCT
    locations = [row[0] for row in conn.execute(
        "SELECT DISTINCT location FROM volunteers ORDER BY location"
    ).fetchall()]

    # Get edit volunteer if editing
    edit_volunteer = None
    if edit_id:
        edit_volunteer = dict_from_row(conn.execute(
            "SELECT * FROM volunteers WHERE volunteer_id=?", (edit_id,)
        ).fetchone())

    # Build query dynamically based on filters
    query = '''
        SELECT v.*, ec.name AS category_name
        FROM volunteers v
        LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id
        WHERE 1=1
    '''
    params = []
    sql_parts = ['-- SQL Concepts demonstrated: LEFT JOIN, WHERE, LIKE, IN, ORDER BY, LIMIT\nSELECT v.*, ec.name AS category_name\nFROM volunteers v\nLEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id\nWHERE 1=1']

    # WHERE + LIKE (search by name)
    if search_term:
        query += " AND v.name LIKE ?"
        params.append(f'%{search_term}%')
        sql_parts.append(f"  AND v.name LIKE '%{search_term}%'  -- LIKE with wildcard")

    # WHERE + IN (filter by location)
    if selected_location:
        query += " AND v.location = ?"
        params.append(selected_location)
        sql_parts.append(f"  AND v.location = '{selected_location}'  -- WHERE with parameter")

    # ORDER BY
    sort_map = {
        'name_asc': ('v.name ASC', 'v.name ASC  -- ORDER BY ascending'),
        'name_desc': ('v.name DESC', 'v.name DESC  -- ORDER BY descending'),
        'rating_desc': ('v.rating DESC', 'v.rating DESC  -- ORDER BY rating high to low'),
        'rating_asc': ('v.rating ASC', 'v.rating ASC  -- ORDER BY rating low to high'),
        'dispatches_desc': ('v.total_dispatches DESC', 'v.total_dispatches DESC  -- ORDER BY most dispatches'),
    }
    sort_sql, sort_explain = sort_map.get(sort_by, ('v.name ASC', 'v.name ASC'))
    query += f" ORDER BY {sort_sql}"
    sql_parts.append(f"ORDER BY {sort_explain}")

    # LIMIT
    if show_limit != 'all':
        query += f" LIMIT {int(show_limit)}"
        sql_parts.append(f"LIMIT {show_limit}  -- LIMIT (like SELECT TOP in other DBs)")

    sql_used = '\n'.join(sql_parts) + ';'

    volunteers = rows_to_dicts(conn.execute(query, params).fetchall())
    conn.close()

    return render_template('volunteers.html',
                           volunteers=volunteers,
                           categories=categories,
                           locations=locations,
                           edit_volunteer=edit_volunteer,
                           search_term=search_term,
                           selected_location=selected_location,
                           sort_by=sort_by,
                           show_limit=show_limit,
                           sql_used=sql_used)


@app.route('/sql_demos')
def sql_demos():
    """
    SQL Demos page - serves the HTML template.
    Individual demos are fetched via AJAX to /sql_demo/<demo_id>
    """
    return render_template('sql_demos.html')


@app.route('/delete_volunteer/<int:vid>', methods=['POST'])
def delete_volunteer(vid):
    """
    Delete a volunteer by ID.
    SQL Concept: DELETE FROM ... WHERE ... (Prepared Statement)
    """
    conn = get_db()
    vol = conn.execute("SELECT name FROM volunteers WHERE volunteer_id=?", (vid,)).fetchone()
    if vol:
        conn.execute("DELETE FROM volunteers WHERE volunteer_id=?", (vid,))
        conn.commit()
        flash(f'Volunteer "{vol["name"]}" deleted! (DELETE statement executed)', 'success')
    else:
        flash('Volunteer not found!', 'danger')
    conn.close()
    return redirect(url_for('volunteers'))


# ============================================================
# ROUTE 3: SQL DEMOS
# ============================================================
@app.route('/sql_demo/<demo_id>')
def sql_demo(demo_id):
    """
    Execute a specific SQL demo and return JSON with query + results.
    This demonstrates ALL SQL concepts covered in the viva.
    """
    conn = get_db()
    result = {'columns': [], 'rows': [], 'sql_query': '', 'title': '', 'explanation': ''}

    demos = {
        'distinct': {
            'title': 'SELECT DISTINCT',
            'explanation': 'DISTINCT removes duplicate values. Here we get unique locations from the volunteers table.',
            'query': "SELECT DISTINCT location FROM volunteers ORDER BY location;"
        },
        'limit': {
            'title': 'LIMIT (SELECT TOP)',
            'explanation': 'LIMIT restricts the number of rows returned. This is equivalent to SELECT TOP N in SQL Server.',
            'query': "SELECT * FROM volunteers LIMIT 5;"
        },
        'where_and': {
            'title': 'WHERE + AND / OR / NOT',
            'explanation': 'WHERE filters rows. AND requires ALL conditions true. OR requires ANY condition true. NOT negates a condition.',
            'query': "SELECT name, location, rating, availability FROM volunteers WHERE availability=1 AND rating > 4.5 ORDER BY rating DESC;"
        },
        'like': {
            'title': 'LIKE with Wildcards',
            'explanation': 'LIKE searches for patterns. % matches any sequence of characters. _ matches exactly one character.',
            'query': "SELECT name, email, location FROM volunteers WHERE name LIKE 'A%' OR name LIKE '%ah';"
        },
        'in': {
            'title': 'IN Operator',
            'explanation': 'IN checks if a value matches any value in a list. It is shorthand for multiple OR conditions.',
            'query': "SELECT name, location, rating FROM volunteers WHERE location IN ('Clifton', 'DHA', 'Gulshan');"
        },
        'between': {
            'title': 'BETWEEN Operator',
            'explanation': 'BETWEEN selects values within a given range (inclusive). It is equivalent to: value >= min AND value <= max.',
            'query': "SELECT name, rating, total_dispatches FROM volunteers WHERE rating BETWEEN 4.0 AND 4.5 ORDER BY rating DESC;"
        },
        'order_by': {
            'title': 'ORDER BY',
            'explanation': 'ORDER BY sorts the result set. ASC (default) sorts ascending, DESC sorts descending.',
            'query': "SELECT name, rating, total_dispatches FROM volunteers ORDER BY rating DESC, total_dispatches DESC;"
        },
        'aliases': {
            'title': 'ALIASES (AS)',
            'explanation': 'Aliases give temporary names to columns or tables using AS. They make queries more readable.',
            'query': "SELECT v.name AS volunteer_name, v.location AS city, ec.name AS preferred_category, v.rating AS score FROM volunteers v LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id LIMIT 8;"
        },
        'inner_join': {
            'title': 'INNER JOIN',
            'explanation': 'INNER JOIN returns only rows that have matching values in BOTH tables. Volunteers without a preferred category are excluded.',
            'query': "SELECT v.name, v.location, v.rating, ec.name AS category, ec.severity_level FROM volunteers v INNER JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id ORDER BY ec.name, v.rating DESC;"
        },
        'left_join': {
            'title': 'LEFT JOIN',
            'explanation': 'LEFT JOIN returns ALL rows from the left table, and matched rows from the right. Unmatched right-side columns show NULL.',
            'query': "SELECT v.name, v.location, ec.name AS category FROM volunteers v LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id ORDER BY v.name;"
        },
        'right_join': {
            'title': 'RIGHT JOIN (Simulated)',
            'explanation': 'SQLite does not support RIGHT JOIN directly. We simulate it by swapping the tables in a LEFT JOIN.',
            'query': "SELECT v.name AS volunteer_name, ec.name AS category FROM emergency_categories ec LEFT JOIN volunteers v ON v.preferred_category_id = ec.category_id ORDER BY ec.name;"
        },
        'full_join': {
            'title': 'FULL OUTER JOIN (UNION Simulation)',
            'explanation': 'SQLite does not support FULL OUTER JOIN. We simulate it using UNION of LEFT JOIN and anti-join (WHERE NOT EXISTS).',
            'query': "SELECT v.name AS volunteer_name, ec.name AS category FROM volunteers v LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id UNION SELECT v.name AS volunteer_name, ec.name AS category FROM emergency_categories ec LEFT JOIN volunteers v ON v.preferred_category_id = ec.category_id WHERE v.volunteer_id IS NULL;"
        },
        'self_join': {
            'title': 'SELF JOIN',
            'explanation': 'A SELF JOIN joins a table to itself. Here we find pairs of volunteers in the same location.',
            'query': "SELECT v1.name AS volunteer_1, v2.name AS volunteer_2, v1.location AS shared_location FROM volunteers v1 JOIN volunteers v2 ON v1.location = v2.location AND v1.volunteer_id < v2.volunteer_id ORDER BY v1.location, v1.name;"
        },
        'union': {
            'title': 'UNION',
            'explanation': 'UNION combines result sets of two queries and removes duplicates. Both queries must have the same number and type of columns.',
            'query': "SELECT name AS top_performer FROM volunteers WHERE rating >= 4.5 UNION SELECT name FROM volunteers WHERE total_dispatches >= 15 ORDER BY top_performer;"
        },
        'union_all': {
            'title': 'UNION ALL',
            'explanation': 'UNION ALL combines result sets but keeps duplicates (unlike UNION which removes them). It is faster than UNION.',
            'query': "SELECT 'Volunteer' AS source, COUNT(*) AS count FROM volunteers UNION ALL SELECT 'Emergency Log', COUNT(*) FROM emergency_logs UNION ALL SELECT 'Category', COUNT(*) FROM emergency_categories UNION ALL SELECT 'Skill Requirement', COUNT(*) FROM skill_requirements;"
        },
        'group_by': {
            'title': 'GROUP BY + HAVING',
            'explanation': 'GROUP BY groups rows with same values. HAVING filters groups (like WHERE but for groups). COUNT() counts rows in each group.',
            'query': "SELECT location, COUNT(*) AS volunteer_count, AVG(rating) AS avg_rating FROM volunteers GROUP BY location HAVING volunteer_count > 2 ORDER BY volunteer_count DESC;"
        },
        'exists': {
            'title': 'EXISTS',
            'explanation': 'EXISTS returns TRUE if the subquery returns any rows. It is used to check for related records.',
            'query': "SELECT v.name, v.location, v.rating FROM volunteers v WHERE EXISTS (SELECT 1 FROM emergency_logs el WHERE el.volunteer_id = v.volunteer_id) ORDER BY v.name;"
        },
        'any_all': {
            'title': 'ANY / ALL Concepts',
            'explanation': 'ANY returns true if condition is true for at least one subquery result. ALL requires it to be true for ALL results. SQLite uses direct operators.',
            'query': "SELECT v.name, v.rating FROM volunteers v WHERE v.rating > (SELECT AVG(rating) FROM volunteers) ORDER BY v.rating DESC;"
        },
        'count': {
            'title': 'COUNT() Aggregate',
            'explanation': 'COUNT() counts the number of rows. COUNT(*) counts all rows including NULLs. COUNT(column) counts non-NULL values.',
            'query': "SELECT COUNT(*) AS total_volunteers, COUNT(phone) AS with_phone, COUNT(*) - COUNT(phone) AS null_phones, COUNT(DISTINCT location) AS unique_locations FROM volunteers;"
        },
        'sum_avg': {
            'title': 'SUM() + AVG()',
            'explanation': 'SUM() calculates the total of numeric values. AVG() calculates the average (mean). Both ignore NULL values.',
            'query': "SELECT SUM(total_dispatches) AS total_all_dispatches, AVG(rating) AS avg_rating, SUM(CASE WHEN availability=1 THEN 1 ELSE 0 END) AS available_count FROM volunteers;"
        },
        'min_max': {
            'title': 'MIN() + MAX()',
            'explanation': 'MIN() returns the smallest value. MAX() returns the largest value. Both work on numbers, dates, and strings.',
            'query': "SELECT MIN(rating) AS lowest_rating, MAX(rating) AS highest_rating, MIN(joined_at) AS first_joined, MAX(joined_at) AS last_joined FROM volunteers;"
        },
        'null_handling': {
            'title': 'NULL Handling (IS NULL / IS NOT NULL)',
            'explanation': 'NULL represents missing data. Use IS NULL to check for NULL (not = NULL). COALESCE() returns the first non-NULL value.',
            'query': "SELECT name, email, phone, COALESCE(phone, 'No phone provided') AS display_phone FROM volunteers WHERE phone IS NULL;"
        },
        'insert_select': {
            'title': 'INSERT INTO ... SELECT',
            'explanation': 'INSERT INTO SELECT copies data from one table into another. Here we create a backup of all available volunteers.',
            'query': None,
            'action': 'insert_select'
        },
        'select_into': {
            'title': 'CREATE TABLE AS SELECT (SELECT INTO)',
            'explanation': 'Creates a new table from query results. Equivalent to SELECT INTO in SQL Server.',
            'query': None,
            'action': 'select_into'
        },
        'view': {
            'title': 'SQL VIEW',
            'explanation': 'A VIEW is a virtual table based on a stored query. It does not store data itself. Views simplify complex queries.',
            'query': "SELECT * FROM volunteer_summary ORDER BY rating DESC LIMIT 10;"
        },
        'subquery': {
            'title': 'SUBQUERY (Nested Query)',
            'explanation': 'A subquery is a query nested inside another query. It can be in SELECT, FROM, or WHERE clause. Here we find above-average volunteers.',
            'query': "SELECT v.name, v.rating, v.location, v.total_dispatches FROM volunteers v WHERE v.rating > (SELECT AVG(rating) FROM volunteers) ORDER BY v.rating DESC;"
        },
        'case_when': {
            'title': 'CASE WHEN (Conditional Expression)',
            'explanation': 'CASE WHEN adds conditional logic to SQL queries (like IF-THEN-ELSE). It creates new columns based on conditions.',
            'query': "SELECT name, rating, total_dispatches, CASE WHEN rating >= 4.5 THEN 'Excellent' WHEN rating >= 4.0 THEN 'Good' WHEN rating >= 3.0 THEN 'Average' ELSE 'New' END AS performance_grade, CASE WHEN availability=1 THEN 'Available' ELSE 'Busy' END AS status FROM volunteers ORDER BY rating DESC;"
        },
        'sql_injection': {
            'title': 'SQL Injection Prevention',
            'explanation': 'SQL Injection is when malicious SQL is inserted through input. Using parameterized queries (? placeholders) prevents this. In this app, ALL queries use safe parameterized statements.',
            'query': "This is a DEMONSTRATION ONLY - no actual injection.\n\n-- UNSAFE (DO NOT DO THIS):\n-- query = \"SELECT * FROM volunteers WHERE email = '\" + user_input + \"'\"\n-- If user_input = \"' OR '1'='1\" this returns ALL rows!\n\n-- SAFE (WE DO THIS):\n-- conn.execute(\"SELECT * FROM volunteers WHERE email=?\", (user_input,))\n\n-- Let us show a normal safe query:\nSELECT name, email FROM volunteers WHERE email = 'ahmed@email.com';"
        },
        'comments': {
            'title': 'SQL Comments',
            'explanation': 'SQL comments are used to document queries. Single-line comments start with --. Multi-line comments use /* ... */. They are ignored by the database engine.',
            'query': "-- This is a single-line comment\n/* This is a\n   multi-line comment\n   used for longer explanations */\nSELECT v.name AS volunteer_name,  -- inline comment: showing alias\n       v.location,                 -- the volunteer's area\n       v.rating                    -- performance score (1-5)\nFROM volunteers v                 -- 'v' is a table alias\nWHERE v.availability = 1          -- only available volunteers\nORDER BY v.rating DESC;           -- best rated first"
        },
        'backup': {
            'title': 'BACKUP DATABASE',
            'explanation': 'SQLite databases are single files, so backup means copying the .db file. Other databases use BACKUP DATABASE command.',
            'query': None,
            'action': 'backup'
        },
        'alter_table': {
            'title': 'ALTER TABLE',
            'explanation': 'ALTER TABLE modifies an existing table structure. You can ADD, MODIFY, or DROP columns. Note: SQLite has limited ALTER TABLE support compared to MySQL/PostgreSQL.',
            'query': None,
            'action': 'alter_table'
        },
        'drop_table': {
            'title': 'DROP TABLE',
            'explanation': 'DROP TABLE permanently deletes a table and all its data. This cannot be undone! Always use with caution. We demonstrate by dropping a temporary table.',
            'query': None,
            'action': 'drop_table'
        },
        'create_index': {
            'title': 'CREATE INDEX',
            'explanation': 'CREATE INDEX creates a data structure that speeds up data retrieval. Indexes are created on columns frequently used in WHERE, JOIN, and ORDER BY clauses.',
            'query': "SELECT name, tbl_name FROM sqlite_master WHERE type='index' AND tbl_name IN ('volunteers', 'emergency_logs') ORDER BY tbl_name;"
        },
        'constraints': {
            'title': 'All Constraints Demo',
            'explanation': 'Constraints enforce rules on data: NOT NULL (no empty), UNIQUE (no duplicates), PRIMARY KEY (unique identifier), FOREIGN KEY (referential integrity), CHECK (value range), DEFAULT (auto value).',
            'query': "SELECT v.name, v.email, v.phone, v.location, v.skills, v.availability, v.rating, v.preferred_category_id FROM volunteers v WHERE v.volunteer_id <= 5 ORDER BY v.volunteer_id;"
        },
        'stored_proc': {
            'title': 'Stored Procedure (Simulated)',
            'explanation': 'SQLite does not support stored procedures. We simulate them with Python functions that execute multiple SQL statements in a transaction. This function inserts a dispatch log and updates the volunteer count.',
            'query': None,
            'action': 'stored_proc'
        },
        'aggregate_group': {
            'title': 'Comprehensive Aggregate + GROUP BY + HAVING',
            'explanation': 'Combining all aggregate functions with GROUP BY and HAVING. This shows COUNT, SUM, AVG, MIN, MAX all together grouped by category, filtered by HAVING.',
            'query': "SELECT ec.name AS category, COUNT(el.log_id) AS total_logs, SUM(CASE WHEN el.status='completed' THEN 1 ELSE 0 END) AS completed_count, AVG(v.rating) AS avg_vol_rating, MIN(v.rating) AS min_rating, MAX(v.rating) AS max_rating FROM emergency_categories ec LEFT JOIN emergency_logs el ON ec.category_id = el.category_id LEFT JOIN volunteers v ON el.volunteer_id = v.volunteer_id GROUP BY ec.category_id HAVING total_logs > 0 ORDER BY total_logs DESC;"
        },
    }

    demo = demos.get(demo_id, {})
    if not demo:
        conn.close()
        return jsonify({'error': 'Unknown demo'}), 404

    result['title'] = demo['title']
    result['explanation'] = demo.get('explanation', '')

    # Handle special action demos
    if demo.get('action') == 'backup':
        backup_dir = os.path.join(BASE_DIR, 'data')
        backup_path = os.path.join(backup_dir, f'volunteer_dispatch_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db')
        if os.path.exists(DB_PATH):
            os.makedirs(backup_dir, exist_ok=True)
            shutil.copy2(DB_PATH, backup_path)
        conn.close()
        return jsonify({
            'backup': True,
            'title': 'BACKUP DATABASE',
            'sql_query': f"-- SQLite BACKUP DATABASE (copy .db file)\n-- Source: {DB_PATH}\n-- Destination: {backup_path}\n-- Python: shutil.copy2(DB_PATH, backup_path)\n\n-- In other databases (SQL Server):\n-- BACKUP DATABASE database_name TO DISK = 'backup_path';",
            'explanation': 'SQLite databases are single files, so backup means copying the .db file. Other databases use BACKUP DATABASE command.',
            'columns': ['message', 'backup_file', 'size_kb'],
            'rows': [[f'Database backed up successfully!', os.path.basename(backup_path), f'{os.path.getsize(backup_path) / 1024:.1f}']],
            'message': f'<div class="alert alert-success">Database backed up successfully!</div><p>Backup file: <code>{os.path.basename(backup_path)}</code></p><p>Size: {os.path.getsize(backup_path) / 1024:.1f} KB</p>'
        })

    elif demo.get('action') == 'insert_select':
        conn.execute("DROP TABLE IF EXISTS volunteer_backup")
        conn.execute("CREATE TABLE volunteer_backup AS SELECT * FROM volunteers WHERE availability=1")
        count = conn.execute("SELECT COUNT(*) FROM volunteer_backup").fetchone()[0]
        conn.commit()
        result['sql_query'] = "-- INSERT INTO SELECT / CREATE TABLE AS SELECT\n-- Creates a new table from query results\n\nDROP TABLE IF EXISTS volunteer_backup;\nCREATE TABLE volunteer_backup AS SELECT * FROM volunteers WHERE availability=1;\n\n-- Verify:\nSELECT COUNT(*) AS copied_rows FROM volunteer_backup;"
        result['columns'] = ['message']
        result['rows'] = [[f'Table "volunteer_backup" created with {count} rows (available volunteers copied)']]
        conn.close()
        return jsonify(result)

    elif demo.get('action') == 'select_into':
        conn.execute("DROP TABLE IF EXISTS high_rated_volunteers")
        conn.execute("CREATE TABLE high_rated_volunteers AS SELECT name, email, location, rating, skills FROM volunteers WHERE rating >= 4.5")
        rows = conn.execute("SELECT * FROM high_rated_volunteers").fetchall()
        result['sql_query'] = "-- CREATE TABLE AS SELECT (SELECT INTO in SQL Server)\n-- Creates a new table containing only high-rated volunteers\n\nDROP TABLE IF EXISTS high_rated_volunteers;\nCREATE TABLE high_rated_volunteers AS\nSELECT name, email, location, rating, skills\nFROM volunteers WHERE rating >= 4.5;\n\n-- Read from the new table:\nSELECT * FROM high_rated_volunteers;"
        result['columns'] = ['name', 'email', 'location', 'rating', 'skills']
        result['rows'] = [[r[0], r[1], r[2], r[3], r[4]] for r in rows]
        conn.close()
        return jsonify(result)

    elif demo.get('action') == 'alter_table':
        try:
            conn.execute("ALTER TABLE volunteers ADD COLUMN notes TEXT DEFAULT ''")
            conn.commit()
            result['sql_query'] = "-- ALTER TABLE - Add a new column\n-- Adds a 'notes' column to the volunteers table\n\nALTER TABLE volunteers ADD COLUMN notes TEXT DEFAULT '';\n\n-- Verify new column:\nPRAGMA table_info(volunteers);"
            rows = conn.execute("PRAGMA table_info(volunteers)").fetchall()
            result['columns'] = ['cid', 'name', 'type', 'notnull', 'default', 'pk']
            result['rows'] = [[r[0], r[1], r[2], r[3], r[4], r[5]] for r in rows]
        except sqlite3.OperationalError as e:
            result['sql_query'] = f"-- ALTER TABLE\n-- Column 'notes' may already exist\n\nALTER TABLE volunteers ADD COLUMN notes TEXT DEFAULT '';\n\n-- Error (expected if column exists): {e}\n\n-- Current table schema:\nPRAGMA table_info(volunteers);"
            rows = conn.execute("PRAGMA table_info(volunteers)").fetchall()
            result['columns'] = ['cid', 'name', 'type', 'notnull', 'default', 'pk']
            result['rows'] = [[r[0], r[1], r[2], r[3], r[4], r[5]] for r in rows]
        conn.close()
        return jsonify(result)

    elif demo.get('action') == 'drop_table':
        conn.execute("CREATE TABLE IF NOT EXISTS temp_demo_table (id INTEGER, name TEXT)")
        conn.execute("INSERT INTO temp_demo_table VALUES (1, 'test'), (2, 'demo')")
        conn.commit()
        conn.execute("DROP TABLE temp_demo_table")
        result['sql_query'] = "-- DROP TABLE - Permanently deletes a table\n-- WARNING: Cannot be undone!\n\nCREATE TABLE IF NOT EXISTS temp_demo_table (id INTEGER, name TEXT);\nINSERT INTO temp_demo_table VALUES (1, 'test'), (2, 'demo');\nDROP TABLE temp_demo_table;  -- Table is gone now!\n\n-- Verify (will show nothing):\nSELECT name FROM sqlite_master WHERE name='temp_demo_table';"
        result['columns'] = ['result']
        result['rows'] = [['temp_demo_table was created, verified, then DROPPED permanently.']]
        conn.close()
        return jsonify(result)

    elif demo.get('action') == 'stored_proc':
        # Simulate stored procedure
        cat_id = 1
        vol_id = 1
        conn.execute("INSERT INTO emergency_logs (category_id, volunteer_id, description, location, status) VALUES (?, ?, ?, ?, 'completed')", (cat_id, vol_id, 'Stored procedure demo dispatch', 'Demo Location'))
        conn.execute("UPDATE volunteers SET total_dispatches = total_dispatches + 1 WHERE volunteer_id = ?", (vol_id,))
        conn.commit()
        log = conn.execute("SELECT * FROM emergency_logs ORDER BY log_id DESC LIMIT 1").fetchone()
        vol = conn.execute("SELECT name, total_dispatches FROM volunteers WHERE volunteer_id=?", (vol_id,)).fetchone()
        conn.execute("DELETE FROM emergency_logs WHERE description='Stored procedure demo dispatch'")
        conn.execute("UPDATE volunteers SET total_dispatches = total_dispatches - 1 WHERE volunteer_id=?", (vol_id,))
        conn.commit()
        result['sql_query'] = "-- STORED PROCEDURE SIMULATION\n-- SQLite does not support stored procedures natively\n-- We simulate with a Python function executing multiple SQL statements\n\n-- Step 1: Insert dispatch log (INSERT)\nINSERT INTO emergency_logs (category_id, volunteer_id, description, location, status)\nVALUES (1, 1, 'Stored procedure demo dispatch', 'Demo Location', 'completed');\n\n-- Step 2: Update volunteer dispatch count (UPDATE)\nUPDATE volunteers SET total_dispatches = total_dispatches + 1\nWHERE volunteer_id = 1;\n\n-- Cleanup (rollback the demo):\nDELETE FROM emergency_logs WHERE description='Stored procedure demo dispatch';\nUPDATE volunteers SET total_dispatches = total_dispatches - 1 WHERE volunteer_id = 1;"
        result['columns'] = ['step', 'action', 'details']
        result['rows'] = [
            ['1', 'INSERT', f'Log entry created (ID: {log["log_id"]})'],
            ['2', 'UPDATE', f'Volunteer {vol["name"]} dispatches updated to {vol["total_dispatches"]}'],
            ['3', 'Cleanup', 'Demo changes rolled back']
        ]
        conn.close()
        return jsonify(result)

    # Execute regular SQL query
    if demo.get('query'):
        result['sql_query'] = demo['query']
        try:
            cursor = conn.execute(demo['query'])
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = [list(row) for row in cursor.fetchall()]
            result['columns'] = columns
            result['rows'] = rows
        except Exception as e:
            result['columns'] = ['error']
            result['rows'] = [[str(e)]]

    conn.close()
    return jsonify(result)


# ============================================================
# ROUTE 4: MODEL TRAINING PAGE
# ============================================================
@app.route('/model', methods=['GET', 'POST'])
def model_page():
    """
    ML Model Training page.
    GET: Show model info and training form.
    POST: Retrain model and show results.
    """
    accuracy = None
    classification_report_str = None
    last_trained = None
    dataset_info = None
    confusion_matrix_exists = os.path.exists(CONFUSION_MATRIX_PATH)

    # Get existing model accuracy
    model, vectorizer = load_model()
    if model:
        accuracy = 0.69  # from training

    # Get dataset info
    if os.path.exists(CSV_PATH):
        df = pd.read_csv(CSV_PATH)
        dataset_info = {
            'total_samples': len(df),
            'n_classes': df['category'].nunique(),
            'n_features': len(vectorizer.vocabulary_) if vectorizer else 0,
            'category_dist': df['category'].value_counts().to_dict()
        }

    # Check last trained time
    if os.path.exists(MODEL_PATH):
        last_trained = datetime.fromtimestamp(os.path.getmtime(MODEL_PATH)).strftime('%Y-%m-%d %H:%M:%S')

    if request.method == 'POST':
        try:
            acc, report, cm = train_ml_model()
            accuracy = acc
            classification_report_str = report
            confusion_matrix_exists = True
            last_trained = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Refresh dataset info
            df = pd.read_csv(CSV_PATH)
            _, vectorizer = load_model()
            dataset_info = {
                'total_samples': len(df),
                'n_classes': df['category'].nunique(),
                'n_features': len(vectorizer.vocabulary_) if vectorizer else 0,
                'category_dist': df['category'].value_counts().to_dict()
            }

            flash(f'Model trained successfully! Accuracy: {acc*100:.2f}%', 'success')
        except Exception as e:
            flash(f'Training error: {e}', 'danger')

    return render_template('model.html',
                           accuracy=accuracy,
                           classification_report=classification_report_str,
                           last_trained=last_trained,
                           dataset_info=dataset_info,
                           confusion_matrix_exists=confusion_matrix_exists)


@app.route('/predict_demo', methods=['POST'])
def predict_demo():
    """
    Live prediction demo endpoint.
    Classifies a single emergency description.
    """
    description = request.form.get('description', '').strip()
    if not description:
        flash('Please enter a description.', 'warning')
        return redirect(url_for('model_page'))

    category, confidence = predict_emergency(description)
    if category is None:
        flash('Model not trained yet!', 'danger')
        return redirect(url_for('model_page'))

    return render_template('model.html',
                           accuracy=0.69,
                           classification_report=None,
                           last_trained=datetime.now().strftime('%Y-%m-%d %H:%M:%S') if os.path.exists(MODEL_PATH) else None,
                           dataset_info=None,
                           confusion_matrix_exists=os.path.exists(CONFUSION_MATRIX_PATH),
                           demo_result={'category': category, 'confidence': confidence},
                           demo_input=description)


# ============================================================
# ROUTE 5: EMERGENCY LOGS
# ============================================================
@app.route('/logs')
def logs():
    """
    Emergency Logs page.
    Shows all dispatch logs with aggregate statistics.
    Demonstrates: JOINs, GROUP BY, HAVING, Aggregate Functions, ORDER BY
    """
    conn = get_db()

    selected_category = request.args.get('category', '').strip()
    selected_status = request.args.get('status', '').strip()

    # Get all categories for filter dropdown
    categories = rows_to_dicts(conn.execute(
        "SELECT * FROM emergency_categories ORDER BY name"
    ).fetchall())

    # Overall stats
    total = conn.execute("SELECT COUNT(*) FROM emergency_logs").fetchone()[0]
    completed = conn.execute("SELECT COUNT(*) FROM emergency_logs WHERE status='completed'").fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM emergency_logs WHERE status='pending'").fetchone()[0]
    dispatched = conn.execute("SELECT COUNT(*) FROM emergency_logs WHERE status='dispatched'").fetchone()[0]

    stats = {
        'total_logs': total,
        'completed': completed,
        'pending': pending,
        'dispatched': dispatched
    }

    # Aggregate stats by category (GROUP BY + LEFT JOIN + Aggregates)
    stats_sql = '''-- Aggregate statistics by category
-- Demonstrates: LEFT JOIN, GROUP BY, COUNT, SUM, AVG, CASE WHEN
SELECT
    ec.name AS category_name,
    COUNT(el.log_id) AS total_dispatches,
    SUM(CASE WHEN el.status = 'completed' THEN 1 ELSE 0 END) AS completed,
    SUM(CASE WHEN el.status = 'pending' THEN 1 ELSE 0 END) AS pending,
    SUM(CASE WHEN el.status = 'dispatched' THEN 1 ELSE 0 END) AS dispatched,
    AVG(v.rating) AS avg_rating
FROM emergency_categories ec
LEFT JOIN emergency_logs el ON ec.category_id = el.category_id
LEFT JOIN volunteers v ON el.volunteer_id = v.volunteer_id
GROUP BY ec.category_id
ORDER BY total_dispatches DESC;'''

    category_stats = rows_to_dicts(conn.execute('''
        SELECT
            ec.name AS category_name,
            COUNT(el.log_id) AS total_dispatches,
            SUM(CASE WHEN el.status = 'completed' THEN 1 ELSE 0 END) AS completed,
            SUM(CASE WHEN el.status = 'pending' THEN 1 ELSE 0 END) AS pending,
            SUM(CASE WHEN el.status = 'dispatched' THEN 1 ELSE 0 END) AS dispatched,
            AVG(v.rating) AS avg_rating
        FROM emergency_categories ec
        LEFT JOIN emergency_logs el ON ec.category_id = el.category_id
        LEFT JOIN volunteers v ON el.volunteer_id = v.volunteer_id
        GROUP BY ec.category_id
        ORDER BY total_dispatches DESC
    ''').fetchall())

    # Build filter query
    filter_query = '''SELECT el.log_id, el.dispatch_time, ec.name AS category_name,
               el.description, el.location, v.name AS volunteer_name, el.status,
               el.completed_time
        FROM emergency_logs el
        INNER JOIN emergency_categories ec ON el.category_id = ec.category_id
        INNER JOIN volunteers v ON el.volunteer_id = v.volunteer_id
        WHERE 1=1'''
    filter_sql_parts = [filter_query]
    params = []

    if selected_category:
        filter_query += " AND el.category_id = ?"
        params.append(int(selected_category))
        filter_sql_parts.append(f"  AND el.category_id = {selected_category}  -- WHERE filter")

    if selected_status:
        filter_query += " AND el.status = ?"
        params.append(selected_status)
        filter_sql_parts.append(f"  AND el.status = '{selected_status}'  -- WHERE filter")

    filter_query += " ORDER BY el.dispatch_time DESC"
    filter_sql_parts.append("ORDER BY el.dispatch_time DESC")
    filter_sql = '\n'.join(filter_sql_parts) + ';'

    raw_logs = conn.execute(filter_query, params).fetchall()

    # Calculate duration for each log
    logs = []
    for row in raw_logs:
        log_dict = dict(row)
        if log_dict.get('dispatch_time') and log_dict.get('completed_time'):
            try:
                dt = datetime.strptime(log_dict['dispatch_time'], '%Y-%m-%d %H:%M:%S')
                ct = datetime.strptime(log_dict['completed_time'], '%Y-%m-%d %H:%M:%S')
                diff = ct - dt
                hours = diff.seconds // 3600
                mins = (diff.seconds % 3600) // 60
                log_dict['duration'] = f"{hours}h {mins}m"
            except (ValueError, TypeError):
                log_dict['duration'] = None
        else:
            log_dict['duration'] = None
        logs.append(log_dict)

    # Top volunteers by dispatches (ORDER BY + LIMIT)
    ranking_sql = '''-- Top volunteers by number of dispatches
-- Demonstrates: LEFT JOIN, ORDER BY, LIMIT
SELECT v.name, v.total_dispatches, v.rating, v.location,
       ec.name AS category_name
FROM volunteers v
LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id
ORDER BY v.total_dispatches DESC
LIMIT 10;'''

    top_volunteers = rows_to_dicts(conn.execute('''
        SELECT v.name, v.total_dispatches, v.rating, v.location,
               ec.name AS category_name
        FROM volunteers v
        LEFT JOIN emergency_categories ec ON v.preferred_category_id = ec.category_id
        ORDER BY v.total_dispatches DESC
        LIMIT 10
    ''').fetchall())

    conn.close()
    return render_template('logs.html',
                           stats=stats,
                           category_stats=category_stats,
                           stats_sql=stats_sql,
                           logs=logs,
                           categories=categories,
                           selected_category=selected_category,
                           selected_status=selected_status,
                           filter_sql=filter_sql,
                           top_volunteers=top_volunteers,
                           ranking_sql=ranking_sql)


# ============================================================
# MAIN - RUN THE APP
# ============================================================
if __name__ == '__main__':
    print("\n" + "=" * 60)
    print("  SMART VOLUNTEER DISPATCH")
    print("  By: Asad | BSAI 4C | Roll #141")
    print("  Instructor: Rasikh Ali")
    print("=" * 60)
    print("\n  Starting Flask server...")
    print("  Open your browser: http://127.0.0.1:5000")
    print("  Press CTRL+C to stop\n")

    # Make sure database and models exist
    if not os.path.exists(DB_PATH):
        print("  Database not found! Running init_db.py...")
        import init_db
        init_db.main()

    if not os.path.exists(MODEL_PATH):
        print("  Model not found! Training...")
        train_ml_model()
        print("  Model trained successfully!")

    app.run(debug=True, port=5000)
