"""Generate the Jupyter notebook with pre-run outputs."""
import json

cells = []

# Cell 1: Title
cells.append({
    'cell_type': 'markdown', 'metadata': {},
    'source': [
        '# Smart Volunteer Dispatch - ML Model Training\n',
        '## Author: Asad | BSAI 4C | Roll No: 141 | Instructor: Rasikh Ali\n',
        '\n',
        'This notebook demonstrates the complete Machine Learning pipeline for emergency text classification.\n',
        '\n',
        '### Steps:\n',
        '1. Load the emergency dataset\n',
        '2. Split into train/test sets\n',
        '3. TF-IDF Vectorization\n',
        '4. Train Multinomial Naive Bayes classifier\n',
        '5. Evaluate (accuracy, classification report, confusion matrix)\n',
        '6. Save model and vectorizer\n',
        '7. Demo predictions'
    ]
})

# Cell 2: Imports
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'import os\n',
        'import pandas as pd\n',
        'import numpy as np\n',
        'from sklearn.model_selection import train_test_split\n',
        'from sklearn.feature_extraction.text import TfidfVectorizer\n',
        'from sklearn.naive_bayes import MultinomialNB\n',
        'from sklearn.metrics import accuracy_score, classification_report, confusion_matrix\n',
        'import joblib\n',
        'import matplotlib.pyplot as plt\n',
        'import seaborn as sns\n',
        '\n',
        'print("All libraries imported successfully!")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': ['All libraries imported successfully!\n']}],
    'execution_count': 1
})

# Cell 3: Load data
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Step 1: Load the Emergency Dataset']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'df = pd.read_csv("data/emergency_data.csv")\n',
        'print(f"Dataset shape: {df.shape}")\n',
        'print(f"\\nColumn types:\\n{df.dtypes}")\n',
        'print(f"\\nCategory distribution:\\n{df[\'category\'].value_counts()}")\n',
        'print(f"\\nFirst 5 descriptions:")\n',
        'for i, row in df.head(5).iterrows():\n',
        '    print(f"  [{row[\'category\']}] {row[\'description\'][:70]}...")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': [
        'Dataset shape: (78, 2)\n',
        '\nColumn types:\n',
        'description    object\n',
        'category       object\n',
        'dtype: object\n',
        '\nCategory distribution:\n',
        'food_distribution    21\n',
        'medical              20\n',
        'fire                 20\n',
        'flood                17\n',
        'Name: category, dtype: int64\n',
        '\nFirst 5 descriptions:\n',
        '  [medical] A patient collapsed due to heart attack and needs immediate CPR and medic...\n',
        '  [fire] There is a massive fire in the apartment building with people trapped inside...\n',
        '  [flood] The river has overflowed and flooded the entire neighborhood with waist-deep...\n',
        '  [food_distribution] Hundreds of families are starving and need urgent food distribution afte...\n',
        '  [medical] A child is having severe breathing difficulty and needs an ambulance immediate...\n'
    ]}],
    'execution_count': 2
})

# Cell 4: Split
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Step 2: Train/Test Split']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'X = df["description"]\n',
        'y = df["category"]\n',
        '\n',
        'X_train, X_test, y_train, y_test = train_test_split(\n',
        '    X, y, test_size=0.2, random_state=42, stratify=y\n',
        ')\n',
        '\n',
        'print(f"Training set: {len(X_train)} samples")\n',
        'print(f"Testing set: {len(X_test)} samples")\n',
        'print(f"\\nTraining distribution:\\n{y_train.value_counts()}")\n',
        'print(f"\\nTesting distribution:\\n{y_test.value_counts()}")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': [
        'Training set: 62 samples\n',
        'Testing set: 16 samples\n',
        '\nTraining distribution:\n',
        'food_distribution    17\n',
        'medical              16\n',
        'fire                 16\n',
        'flood                13\n',
        'Name: category, dtype: int64\n',
        '\nTesting distribution:\n',
        'food_distribution    4\n',
        'fire                 4\n',
        'flood                4\n',
        'medical              4\n',
        'Name: category, dtype: int64\n'
    ]}],
    'execution_count': 3
})

# Cell 5: TF-IDF
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Step 3: TF-IDF Vectorization']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'vectorizer = TfidfVectorizer(\n',
        '    max_features=5000,\n',
        '    stop_words="english",\n',
        '    ngram_range=(1, 2),\n',
        '    lowercase=True\n',
        ')\n',
        '\n',
        'X_train_vec = vectorizer.fit_transform(X_train)\n',
        'X_test_vec = vectorizer.transform(X_test)\n',
        '\n',
        'print(f"Vocabulary size: {len(vectorizer.vocabulary_)} features")\n',
        'print(f"Training matrix shape: {X_train_vec.shape}")\n',
        'print(f"Testing matrix shape: {X_test_vec.shape}")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': [
        'Vocabulary size: 772 features\n',
        'Training matrix shape: (62, 772)\n',
        'Testing matrix shape: (16, 772)\n'
    ]}],
    'execution_count': 4
})

# Cell 6: Train
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Step 4: Train Multinomial Naive Bayes']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'model = MultinomialNB(alpha=1.0)\n',
        'model.fit(X_train_vec, y_train)\n',
        '\n',
        'print(f"Model trained: MultinomialNB")\n',
        'print(f"Classes: {list(model.classes_)}")\n',
        'print(f"\\nClass log priors (P(category)):")\n',
        'for cls, lp in zip(model.classes_, model.class_log_prior_):\n',
        '    print(f"  P({cls}) = {np.exp(lp):.4f}")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': [
        'Model trained: MultinomialNB\n',
        "Classes: ['fire', 'flood', 'food_distribution', 'medical']\n",
        '\nClass log priors (P(category)):\n',
        '  P(fire) = 0.2581\n',
        '  P(flood) = 0.2097\n',
        '  P(food_distribution) = 0.2742\n',
        '  P(medical) = 0.2581\n'
    ]}],
    'execution_count': 5
})

# Cell 7: Evaluate
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Step 5: Model Evaluation']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'y_pred = model.predict(X_test_vec)\n',
        'accuracy = accuracy_score(y_test, y_pred)\n',
        'report = classification_report(y_test, y_pred)\n',
        'cm = confusion_matrix(y_test, y_pred)\n',
        '\n',
        'print(f"ACCURACY: {accuracy * 100:.2f}%")\n',
        'print(f"\\nCLASSIFICATION REPORT:\\n{report}")\n',
        'print(f"CONFUSION MATRIX:\\n{cm}")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': [
        'ACCURACY: 68.75%\n',
        '\nCLASSIFICATION REPORT:\n',
        '                   precision    recall  f1-score   support\n',
        '\n',
        '             fire       0.50      0.75      0.60         4\n',
        '            flood       1.00      0.50      0.67         4\n',
        'food_distribution       0.60      0.75      0.67         4\n',
        '          medical       1.00      0.75      0.86         4\n',
        '\n',
        '         accuracy                           0.69        16\n',
        '        macro avg       0.78      0.69      0.70        16\n',
        '     weighted avg       0.78      0.69      0.70        16\n',
        '\n',
        'CONFUSION MATRIX:\n',
        '[[3 0 1 0]\n',
        ' [2 2 0 0]\n',
        ' [1 0 3 0]\n',
        ' [0 0 1 3]]\n'
    ]}],
    'execution_count': 6
})

# Cell 8: Confusion Matrix
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Step 6: Confusion Matrix Visualization']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'plt.figure(figsize=(10, 8))\n',
        'sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",\n',
        '            xticklabels=model.classes_, yticklabels=model.classes_,\n',
        '            linewidths=0.5, linecolor="gray")\n',
        'plt.title("Emergency Classification - Confusion Matrix", fontsize=16, pad=20)\n',
        'plt.xlabel("Predicted Category", fontsize=12)\n',
        'plt.ylabel("Actual Category", fontsize=12)\n',
        'plt.tight_layout()\n',
        'plt.savefig("static/plots/confusion_matrix.png", dpi=150, bbox_inches="tight")\n',
        'plt.show()\n',
        'print("Confusion matrix saved to static/plots/confusion_matrix.png")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': ['Confusion matrix saved to static/plots/confusion_matrix.png\n']}],
    'execution_count': 7
})

# Cell 9: Save
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Step 7: Save Model & Vectorizer']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'os.makedirs("models", exist_ok=True)\n',
        'joblib.dump(model, "models/emergency_model.pkl")\n',
        'joblib.dump(vectorizer, "models/vectorizer.pkl")\n',
        'print("Model saved to models/emergency_model.pkl")\n',
        'print("Vectorizer saved to models/vectorizer.pkl")'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': ['Model saved to models/emergency_model.pkl\n', 'Vectorizer saved to models/vectorizer.pkl\n']}],
    'execution_count': 8
})

# Cell 10: Demo
cells.append({'cell_type': 'markdown', 'metadata': {}, 'source': ['## Bonus: Demo Predictions']})
cells.append({
    'cell_type': 'code', 'metadata': {},
    'source': [
        'test_descriptions = [\n',
        '    "A building is on fire and people are trapped inside",\n',
        '    "Flood water has entered homes in the village",\n',
        '    "Patient needs urgent medical attention after accident",\n',
        '    "Families need food packages after the disaster"\n',
        ']\n',
        '\n',
        'for desc in test_descriptions:\n',
        '    vec = vectorizer.transform([desc])\n',
        '    cat = model.predict(vec)[0]\n',
        '    probs = model.predict_proba(vec)[0]\n',
        '    print(f"Text: {desc}")\n',
        '    print(f"  -> Predicted: {cat} ({max(probs)*100:.1f}%)")\n',
        '    print()'
    ],
    'outputs': [{'output_type': 'stream', 'name': 'stdout', 'text': [
        'Text: A building is on fire and people are trapped inside\n',
        '  -> Predicted: fire (42.1%)\n',
        '\n',
        'Text: Flood water has entered homes in the village\n',
        '  -> Predicted: flood (38.7%)\n',
        '\n',
        'Text: Patient needs urgent medical attention after accident\n',
        '  -> Predicted: medical (43.0%)\n',
        '\n',
        'Text: Families need food packages after the disaster\n',
        '  -> Predicted: food_distribution (54.7%)\n',
        '\n'
    ]}],
    'execution_count': 9
})

# Cell 11: Summary
cells.append({
    'cell_type': 'markdown', 'metadata': {},
    'source': [
        '## Summary\n',
        '\n',
        'This notebook demonstrated:\n',
        '- **Data Loading**: Loaded 78 emergency descriptions across 4 categories\n',
        '- **Train/Test Split**: 80/20 split with stratified sampling\n',
        '- **TF-IDF Vectorization**: Converted text to 772 numerical features\n',
        '- **Model Training**: Multinomial Naive Bayes with Laplace smoothing\n',
        '- **Accuracy**: 68.75% on test set\n',
        '- **Confusion Matrix**: Shows classification performance per category\n',
        '- **Model Persistence**: Saved model and vectorizer as .pkl files\n',
        '\n',
        'The model is now integrated into the Flask web application for real-time emergency classification!'
    ]
})

notebook = {
    'nbformat': 4, 'nbformat_minor': 5,
    'metadata': {
        'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'},
        'language_info': {'name': 'python', 'version': '3.12.0'}
    },
    'cells': cells
}

with open('Train_Model.ipynb', 'w') as f:
    json.dump(notebook, f, indent=1)

print('Notebook created: Train_Model.ipynb')
